/**
 * JavaScript Principal
 * Sistema de Gestão de Terceiros
 */

// Configurações globais
const CONFIG = {
    API_BASE_URL: 'api',
    ITEMS_PER_PAGE: 20,
    CSRF_TOKEN: document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
};

// Utilitários
const Utils = {
    // Formatar CPF
    formatCPF(cpf) {
        return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    },

    // Formatar CNPJ
    formatCNPJ(cnpj) {
        return cnpj.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    },

    // Formatar data
    formatDate(date) {
        if (!date) return '-';
        const d = new Date(date);
        return d.toLocaleDateString('pt-BR');
    },

    // Validar CPF
    validateCPF(cpf) {
        cpf = cpf.replace(/[^\d]/g, '');
        
        if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) {
            return false;
        }
        
        let sum = 0;
        for (let i = 0; i < 9; i++) {
            sum += parseInt(cpf.charAt(i)) * (10 - i);
        }
        let remainder = (sum * 10) % 11;
        if (remainder === 10 || remainder === 11) remainder = 0;
        if (remainder !== parseInt(cpf.charAt(9))) return false;
        
        sum = 0;
        for (let i = 0; i < 10; i++) {
            sum += parseInt(cpf.charAt(i)) * (11 - i);
        }
        remainder = (sum * 10) % 11;
        if (remainder === 10 || remainder === 11) remainder = 0;
        if (remainder !== parseInt(cpf.charAt(10))) return false;
        
        return true;
    },

    // Validar CNPJ
    validateCNPJ(cnpj) {
        cnpj = cnpj.replace(/[^\d]/g, '');
        
        if (cnpj.length !== 14 || /^(\d)\1{13}$/.test(cnpj)) {
            return false;
        }
        
        let length = cnpj.length - 2;
        let numbers = cnpj.substring(0, length);
        let digits = cnpj.substring(length);
        let sum = 0;
        let pos = length - 7;
        
        for (let i = length; i >= 1; i--) {
            sum += numbers.charAt(length - i) * pos--;
            if (pos < 2) pos = 9;
        }
        
        let result = sum % 11 < 2 ? 0 : 11 - sum % 11;
        if (result !== parseInt(digits.charAt(0))) return false;
        
        length = length + 1;
        numbers = cnpj.substring(0, length);
        sum = 0;
        pos = length - 7;
        
        for (let i = length; i >= 1; i--) {
            sum += numbers.charAt(length - i) * pos--;
            if (pos < 2) pos = 9;
        }
        
        result = sum % 11 < 2 ? 0 : 11 - sum % 11;
        return result === parseInt(digits.charAt(1));
    },

    // Debounce function
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Mostrar loading
    showLoading(element) {
        if (element) {
            element.innerHTML = '<i class="loading"></i> Carregando...';
            element.disabled = true;
        }
    },

    // Esconder loading
    hideLoading(element, originalText) {
        if (element) {
            element.innerHTML = originalText;
            element.disabled = false;
        }
    },

    // Mostrar toast
    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `alert alert-${type} toast`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-circle' : 'info-circle'}"></i>
            ${message}
        `;
        
        // Adicionar estilos do toast
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            animation: slideInRight 0.3s ease;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
    }
};

// Gerenciador de API
const API = {
    async request(endpoint, options = {}) {
        const url = `${CONFIG.API_BASE_URL}${endpoint}`;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': CONFIG.CSRF_TOKEN
            }
        };
        
        const config = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Erro na requisição');
            }
            
            return data;
        } catch (error) {
            console.error('Erro na API:', error);
            throw error;
        }
    },

    // Funcionários
    funcionarios: {
        list(params = {}) {
            const query = new URLSearchParams(params).toString();
            return API.request(`/funcionarios.php?${query}`);
        },
        
        get(id) {
            return API.request(`/funcionarios.php?id=${id}`);
        },
        
        create(data) {
            return API.request('/funcionarios.php', {
                method: 'POST',
                body: JSON.stringify(data)
            });
        },
        
        update(id, data) {
            return API.request(`/funcionarios.php?id=${id}`, {
                method: 'PUT',
                body: JSON.stringify(data)
            });
        },
        
        delete(id) {
            return API.request(`/funcionarios.php?id=${id}`, {
                method: 'DELETE'
            });
        }
    },

    // Dashboard
    dashboard: {
        getStats() {
            return API.request('/dashboard.php?action=stats');
        },
        
        getFuncionariosStatus(limit = 50) {
            return API.request(`/dashboard.php?action=funcionarios_status&limit=${limit}`);
        },
        
        getAlertas() {
            return API.request('/dashboard.php?action=alertas');
        },
        
        getGraficos() {
            return API.request('/dashboard.php?action=graficos');
        }
    },

    // Upload
    upload: {
        file(file, type = 'general') {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('type', type);
            formData.append('action', 'upload_file');
            
            return API.request('/upload.php', {
                method: 'POST',
                headers: {
                    'X-CSRF-Token': CONFIG.CSRF_TOKEN
                },
                body: formData
            });
        },
        
        importCSV(file, entity = 'funcionarios') {
            const formData = new FormData();
            formData.append('csv_file', file);
            formData.append('entity', entity);
            formData.append('action', 'import_csv');
            
            return API.request('/upload.php', {
                method: 'POST',
                headers: {
                    'X-CSRF-Token': CONFIG.CSRF_TOKEN
                },
                body: formData
            });
        }
    }
};

// Gerenciador de Modal
const Modal = {
    show(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    },

    hide(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    },

    create(title, content, actions = []) {
        const modalId = 'dynamic-modal-' + Date.now();
        const modal = document.createElement('div');
        modal.id = modalId;
        modal.className = 'modal';
        
        const actionsHTML = actions.map(action => 
            `<button type="button" class="btn ${action.class || 'btn-secondary'}" onclick="${action.onclick || ''}">${action.text}</button>`
        ).join('');
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${title}</h5>
                    <button type="button" class="modal-close" onclick="Modal.hide('${modalId}')">&times;</button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
                <div class="modal-footer">
                    ${actionsHTML}
                    <button type="button" class="btn btn-secondary" onclick="Modal.hide('${modalId}')">Fechar</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        this.show(modalId);
        
        return modalId;
    }
};

// Gerenciador de Formulários
const FormManager = {
    validate(form) {
        const inputs = form.querySelectorAll('[required]');
        let isValid = true;
        
        inputs.forEach(input => {
            const value = input.value.trim();
            const type = input.type;
            
            // Remove classes anteriores
            input.classList.remove('is-valid', 'is-invalid');
            
            // Validação básica
            if (!value) {
                this.showFieldError(input, 'Este campo é obrigatório');
                isValid = false;
                return;
            }
            
            // Validações específicas
            if (type === 'email' && !this.validateEmail(value)) {
                this.showFieldError(input, 'Email inválido');
                isValid = false;
                return;
            }
            
            if (input.dataset.type === 'cpf' && !Utils.validateCPF(value)) {
                this.showFieldError(input, 'CPF inválido');
                isValid = false;
                return;
            }
            
            if (input.dataset.type === 'cnpj' && !Utils.validateCNPJ(value)) {
                this.showFieldError(input, 'CNPJ inválido');
                isValid = false;
                return;
            }
            
            // Campo válido
            this.showFieldSuccess(input);
        });
        
        return isValid;
    },

    showFieldError(input, message) {
        input.classList.add('is-invalid');
        
        let feedback = input.parentNode.querySelector('.invalid-feedback');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            input.parentNode.appendChild(feedback);
        }
        feedback.textContent = message;
    },

    showFieldSuccess(input) {
        input.classList.add('is-valid');
        
        const feedback = input.parentNode.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.remove();
        }
    },

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    serialize(form) {
        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        return data;
    }
};

// Gerenciador de Tabelas
const TableManager = {
    init(tableId, options = {}) {
        const table = document.getElementById(tableId);
        if (!table) return;
        
        const config = {
            sortable: true,
            searchable: true,
            pagination: true,
            ...options
        };
        
        if (config.searchable) {
            this.addSearch(table);
        }
        
        if (config.sortable) {
            this.addSort(table);
        }
        
        if (config.pagination) {
            this.addPagination(table);
        }
    },

    addSearch(table) {
        const searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.className = 'form-control';
        searchInput.placeholder = 'Buscar...';
        searchInput.style.marginBottom = '20px';
        
        table.parentNode.insertBefore(searchInput, table);
        
        searchInput.addEventListener('input', Utils.debounce((e) => {
            this.filterTable(table, e.target.value);
        }, 300));
    },

    filterTable(table, searchTerm) {
        const rows = table.querySelectorAll('tbody tr');
        const term = searchTerm.toLowerCase();
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(term) ? '' : 'none';
        });
    },

    addSort(table) {
        const headers = table.querySelectorAll('thead th');
        
        headers.forEach((header, index) => {
            if (header.dataset.sortable !== 'false') {
                header.style.cursor = 'pointer';
                header.innerHTML += ' <i class="fas fa-sort"></i>';
                
                header.addEventListener('click', () => {
                    this.sortTable(table, index);
                });
            }
        });
    },

    sortTable(table, columnIndex) {
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        const header = table.querySelectorAll('thead th')[columnIndex];
        
        const isAscending = !header.classList.contains('sort-asc');
        
        // Remove classes de ordenação de todos os headers
        table.querySelectorAll('thead th').forEach(th => {
            th.classList.remove('sort-asc', 'sort-desc');
            const icon = th.querySelector('i');
            if (icon) icon.className = 'fas fa-sort';
        });
        
        // Adiciona classe ao header atual
        header.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
        const icon = header.querySelector('i');
        if (icon) {
            icon.className = `fas fa-sort-${isAscending ? 'up' : 'down'}`;
        }
        
        // Ordena as linhas
        rows.sort((a, b) => {
            const aText = a.cells[columnIndex].textContent.trim();
            const bText = b.cells[columnIndex].textContent.trim();
            
            // Tenta converter para número
            const aNum = parseFloat(aText.replace(/[^\d.-]/g, ''));
            const bNum = parseFloat(bText.replace(/[^\d.-]/g, ''));
            
            if (!isNaN(aNum) && !isNaN(bNum)) {
                return isAscending ? aNum - bNum : bNum - aNum;
            }
            
            // Comparação de texto
            return isAscending ? 
                aText.localeCompare(bText) : 
                bText.localeCompare(aText);
        });
        
        // Reinsere as linhas ordenadas
        rows.forEach(row => tbody.appendChild(row));
    }
};

// Inicialização quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar sidebar toggle
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
        });
    }
    
    // Inicializar modais
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    });
    
    // Máscaras de input
    document.querySelectorAll('[data-mask="cpf"]').forEach(input => {
        input.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            e.target.value = value;
        });
    });
    
    document.querySelectorAll('[data-mask="cnpj"]').forEach(input => {
        input.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(\d{2})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1/$2');
            value = value.replace(/(\d{4})(\d{1,2})$/, '$1-$2');
            e.target.value = value;
        });
    });
    
    // Auto-resize textareas
    document.querySelectorAll('textarea').forEach(textarea => {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        });
    });
    
    // Confirmar exclusões
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('btn-delete') || e.target.closest('.btn-delete')) {
            e.preventDefault();
            
            const confirmed = confirm('Tem certeza que deseja excluir este item?');
            if (confirmed) {
                // Prosseguir com a exclusão
                const href = e.target.href || e.target.closest('a').href;
                if (href) {
                    window.location.href = href;
                }
            }
        }
    });
    
    console.log('Sistema de Gestão de Terceiros - JavaScript carregado');
});

// Exportar para uso global
window.Utils = Utils;
window.API = API;
window.Modal = Modal;
window.FormManager = FormManager;
window.TableManager = TableManager;

