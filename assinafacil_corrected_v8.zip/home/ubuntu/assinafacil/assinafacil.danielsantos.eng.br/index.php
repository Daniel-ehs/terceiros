<?php
/**
 * Página de Login
 * Sistema de Gestão de Terceiros
 */

require_once 'config/config.php';
require_once 'includes/functions.php';

// Se já estiver logado, redireciona para o dashboard
if (isValidSession()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitizeInput($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $csrfToken = $_POST['csrf_token'] ?? '';
    
    // Verificar CSRF token
    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Token de segurança inválido. Tente novamente.';
    } else {
        try {
            $db = getDB();
            
            // Buscar usuário
            $user = $db->fetch(
                "SELECT id, nome, email, senha, hierarquia, empresa_id, filiais_permitidas, ativo 
                 FROM usuarios WHERE email = ? AND ativo = TRUE",
                [$email]
            );
            
            if ($user && password_verify($senha, $user['senha'])) {
                // Login bem-sucedido
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['nome'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_hierarchy'] = $user['hierarquia'];
                $_SESSION['user_empresa_id'] = $user['empresa_id'];
                $_SESSION['user_filiais_permitidas'] = $user['filiais_permitidas'];
                $_SESSION['last_activity'] = time();
                
                // Atualizar último login
                $db->execute("UPDATE usuarios SET ultimo_login = NOW() WHERE id = ?", [$user['id']]);
                
                // Log de auditoria
                logAuditoria('usuarios', $user['id'], 'login', null, ['email' => $email]);
                
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Email ou senha incorretos.';
            }
        } catch (Exception $e) {
            error_log("Erro no login: " . $e->getMessage());
            $error = 'Erro interno. Tente novamente mais tarde.';
        }
    }
}
?>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Gestão de Terceiros</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }
        
        .login-container {
            background: var(--white);
            border-radius: var(--border-radius-large);
            box-shadow: var(--shadow-heavy);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        
        .login-logo {
            font-size: 3rem;
            color: var(--primary-green);
            margin-bottom: 10px;
        }
        
        .login-title {
            font-size: 1.8rem;
            color: var(--primary-green);
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .login-subtitle {
            color: var(--gray);
            margin-bottom: 30px;
            font-size: 0.95rem;
        }
        
        .login-form {
            text-align: left;
        }
        
        .login-form .form-group {
            margin-bottom: 25px;
        }
        
        .login-form .form-control {
            padding: 15px;
            font-size: 1rem;
            border-radius: var(--border-radius);
        }
        
        .login-btn {
            width: 100%;
            padding: 15px;
            font-size: 1.1rem;
            font-weight: 600;
            margin-top: 10px;
        }
        
        .login-error {
            background: rgba(244, 67, 54, 0.1);
            color: var(--danger);
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            border-left: 4px solid var(--danger);
            text-align: left;
        }
        
        .login-footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--light-green);
            font-size: 0.85rem;
            color: var(--gray);
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            z-index: 1;
        }
        
        .input-group .form-control {
            padding-left: 45px;
        }
        
        @media (max-width: 480px) {
            .login-container {
                margin: 20px;
                padding: 30px 25px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container fade-in">
        <div class="login-logo">
            <i class="fas fa-users-cog"></i>
        </div>
        
        <h1 class="login-title">Gestão de Terceiros</h1>
        <p class="login-subtitle">Faça login para acessar o sistema</p>
        
        <?php if ($error): ?>
        <div class="login-error">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>
        
        <form method="POST" class="login-form" id="loginForm">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            
            <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <div class="input-group">
                    <i class="fas fa-envelope"></i>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        class="form-control" 
                        placeholder="Digite seu email"
                        value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                        required
                        autocomplete="email"
                    >
                </div>
            </div>
            
            <div class="form-group">
                <label for="senha" class="form-label">Senha</label>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input 
                        type="password" 
                        id="senha" 
                        name="senha" 
                        class="form-control" 
                        placeholder="Digite sua senha"
                        required
                        autocomplete="current-password"
                    >
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary login-btn">
                <i class="fas fa-sign-in-alt"></i>
                Entrar
            </button>
        </form>
        
        <div class="login-footer">
            <p>
                <i class="fas fa-shield-alt"></i>
                Acesso seguro e protegido
            </p>
            <p style="margin-top: 10px;">
                &copy; <?php echo date('Y'); ?> Sistema de Gestão de Terceiros
            </p>
        </div>
    </div>
    
    <script>
        // Adicionar efeitos visuais ao formulário
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('loginForm');
            const inputs = form.querySelectorAll('.form-control');
            
            // Efeito de foco nos inputs
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentNode.style.transform = 'scale(1.02)';
                    this.parentNode.style.transition = 'transform 0.2s ease';
                });
                
                input.addEventListener('blur', function() {
                    this.parentNode.style.transform = 'scale(1)';
                });
            });
            
            // Validação em tempo real
            form.addEventListener('submit', function(e) {
                const email = document.getElementById('email').value;
                const senha = document.getElementById('senha').value;
                
                if (!email || !senha) {
                    e.preventDefault();
                    alert('Por favor, preencha todos os campos.');
                    return;
                }
                
                // Mostrar loading no botão
                const btn = form.querySelector('button[type="submit"]');
                btn.innerHTML = '<i class="loading"></i> Entrando...';
                btn.disabled = true;
            });
            
            // Auto-focus no primeiro campo
            document.getElementById('email').focus();
        });
    </script>
</body>
</html>
