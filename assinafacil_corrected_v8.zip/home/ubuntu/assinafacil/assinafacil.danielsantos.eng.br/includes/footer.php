        </main>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div>
            <p>&copy; <?php echo date('Y'); ?> <?php echo getConfig('empresa_nome', 'Sua Empresa Ltda'); ?> - Sistema de Gestão de Terceiros</p>
            <p style="font-size: 0.8rem; opacity: 0.8;">
                Versão <?php echo getConfig('sistema_versao', '1.0.0'); ?> | 
                Desenvolvido com <i class="fas fa-heart" style="color: #e74c3c;"></i> para sua segurança
            </p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="assets/js/main.js"></script>
    
    <?php if (isset($additionalJS)): ?>
        <?php foreach ($additionalJS as $js): ?>
            <script src="<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <?php if (isset($inlineJS)): ?>
        <script>
            <?php echo $inlineJS; ?>
        </script>
    <?php endif; ?>
</body>
</html>

