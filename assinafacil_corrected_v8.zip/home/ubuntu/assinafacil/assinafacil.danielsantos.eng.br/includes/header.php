<?php
/**
 * Header Comum
 * Sistema de Gestão de Terceiros
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

// Verifica se o usuário está logado
if (!isValidSession()) {
    redirectToLogin();
}

$userName = $_SESSION['user_name'] ?? 'Usuário';
$userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
$userInitials = strtoupper(substr($userName, 0, 2));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generateCSRFToken(); ?>">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' : ''; ?>Sistema de Gestão de Terceiros</title>
    
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">
    
    <?php if (isset($additionalCSS)): ?>
        <?php foreach ($additionalCSS as $css): ?>
            <link rel="stylesheet" href="<?php echo $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <div class="app-container">
        <!-- Header -->
        <header class="header">
            <a href="dashboard.php" class="logo">
                <i class="fas fa-users-cog"></i>
                <span>Gestão de Terceiros</span>
            </a>
            
            <div class="user-menu">
                <div class="user-info">
                    <div class="user-avatar"><?php echo $userInitials; ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($userName); ?></div>
                        <div style="font-size: 0.8rem; opacity: 0.8;">
                            <?php echo ucfirst($userHierarchy); ?>
                        </div>
                    </div>
                </div>
                
                <a href="logout.php" class="logout-btn" title="Sair do sistema">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </header>

        <!-- Sidebar -->
        <nav class="sidebar" id="sidebar">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="sidebar-menu">
                <li>
                    <a href="dashboard.php" class="<?php echo basename($_SERVER["PHP_SELF"]) === "dashboard.php" ? "active" : ""; ?>">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li>
                    <a href="modules/funcionarios/" class="<?php echo strpos($_SERVER["REQUEST_URI"], "/funcionarios/") !== false ? "active" : ""; ?>">
                        <i class="fas fa-users"></i>
                        <span>Funcionários</span>
                        <?php
                        // Buscar alertas de funcionários
                        try {
                            $db = getDB();
                            $alertCount = $db->fetch("
                                SELECT COUNT(*) as total FROM (
                                    SELECT f.id FROM funcionarios f 
                                    WHERE f.status = 'ativo' 
                                    AND (f.aso_validade < CURDATE() OR f.aso_validade BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY))
                                    UNION
                                    SELECT DISTINCT f.id FROM funcionarios f
                                    JOIN funcionario_treinamentos ft ON f.id = ft.funcionario_id
                                    WHERE f.status = 'ativo' 
                                    AND ft.data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                                ) as alertas
                            ")['total'];
                            
                            if ($alertCount > 0) {
                                echo '<span class="menu-badge">' . $alertCount . '</span>';
                            }
                        } catch (Exception $e) {
                            // Silencioso em caso de erro
                        }
                        ?>
                    </a>
                </li>
                
                <li>
                    <a href="modules/empresas/" class="<?php echo strpos($_SERVER["REQUEST_URI"], "/empresas/") !== false ? "active" : ""; ?>">
                        <i class="fas fa-building"></i>
                        <span>Empresas</span>
                    </a>
                </li>
                
                <li>
                    <a href="modules/filiais/" class="<?php echo strpos($_SERVER["REQUEST_URI"], "/filiais/") !== false ? "active" : ""; ?>">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Filiais</span>
                    </a>
                </li>
                
                <li>
                    <a href="modules/treinamentos/" class="<?php echo strpos($_SERVER["REQUEST_URI"], "/treinamentos/") !== false ? "active" : ""; ?>">
                        <i class="fas fa-graduation-cap"></i>
                        <span>Treinamentos</span>
                    </a>
                </li>
                
                <li>
                    <a href="modules/relatorios/" class="<?php echo strpos($_SERVER["REQUEST_URI"], "/relatorios/") !== false ? "active" : ""; ?>">
                        <i class="fas fa-chart-bar"></i>
                        <span>Relatórios</span>
                    </a>
                </li>
                
                <?php if (hasPermission('manage_users')): ?>
                <li>
                    <a href="modules/usuarios/" class="<?php echo strpos($_SERVER["REQUEST_URI"], "/usuarios/") !== false ? "active" : ""; ?>">
                        <i class="fas fa-user-cog"></i>
                        <span>Usuários</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (hasPermission('manage_system')): ?>
                <li>
                    <a href="modules/configuracoes/" class="<?php echo strpos($_SERVER["REQUEST_URI"], "/configuracoes/") !== false ? "active" : ""; ?>">
                        <i class="fas fa-cogs"></i>
                        <span>Configurações</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Conteúdo Principal -->
        <main class="main-content" id="mainContent">
            <?php
            // Exibir mensagens de feedback
            $message = getMessage();
            if ($message):
            ?>
            <div class="alert alert-<?php echo $message['type']; ?> fade-in">
                <i class="fas fa-<?php echo $message['type'] === 'success' ? 'check-circle' : ($message['type'] === 'danger' ? 'exclamation-circle' : 'info-circle'); ?>"></i>
                <?php echo htmlspecialchars($message['text']); ?>
            </div>
            <?php endif; ?>
            
            <!-- Breadcrumb -->
            <?php if (isset($breadcrumb) && !empty($breadcrumb)): ?>
            <nav aria-label="breadcrumb" style="margin-bottom: 20px;">
                <ol style="display: flex; list-style: none; padding: 0; margin: 0; font-size: 0.9rem; color: var(--gray);">
                    <li><a href="dashboard.php" style="color: var(--primary-green); text-decoration: none;">Dashboard</a></li>
                    <?php foreach ($breadcrumb as $item): ?>
                        <li style="margin: 0 10px;">/</li>
                        <?php if (isset($item['url'])): ?>
                            <li><a href="<?php echo $item['url']; ?>" style="color: var(--primary-green); text-decoration: none;"><?php echo $item['title']; ?></a></li>
                        <?php else: ?>
                            <li style="color: var(--dark-gray);"><?php echo $item['title']; ?></li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ol>
            </nav>
            <?php endif; ?>
