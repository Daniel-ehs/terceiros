<?php
/**
 * Funções Auxiliares
 * Sistema de Gestão de Terceiros
 */

/**
 * Registra uma ação na auditoria
 */
function logAuditoria($tabela, $registroId, $acao, $dadosAnteriores = null, $dadosNovos = null) {
    try {
        $db = getDB();
        $usuarioId = $_SESSION['user_id'] ?? 0;
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $sql = "INSERT INTO auditoria (usuario_id, tabela, registro_id, acao, dados_anteriores, dados_novos, ip_address, user_agent) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $params = [
            $usuarioId,
            $tabela,
            $registroId,
            $acao,
            $dadosAnteriores ? json_encode($dadosAnteriores) : null,
            $dadosNovos ? json_encode($dadosNovos) : null,
            $ipAddress,
            $userAgent
        ];
        
        $db->execute($sql, $params);
    } catch (Exception $e) {
        error_log("Erro ao registrar auditoria: " . $e->getMessage());
    }
}

/**
 * Envia email
 */
function sendEmail($to, $subject, $body, $isHTML = true) {
    // Implementação básica - pode ser melhorada com PHPMailer
    $headers = [
        'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM_EMAIL . '>',
        'Reply-To: ' . MAIL_FROM_EMAIL,
        'X-Mailer: PHP/' . phpversion()
    ];
    
    if ($isHTML) {
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-type: text/html; charset=UTF-8';
    }
    
    return mail($to, $subject, $body, implode("\r\n", $headers));
}

/**
 * Gera alertas de vencimento
 */
function generateExpirationAlerts() {
    try {
        $db = getDB();
        
        // Alertas de ASO
        $sql = "SELECT f.id, f.nome, f.aso_validade, e.razao_social as empresa, 
                       fil.nome as filial, u.email
                FROM funcionarios f
                JOIN empresas e ON f.empresa_id = e.id
                JOIN filiais fil ON f.filial_id = fil.id
                LEFT JOIN usuarios u ON u.empresa_id = e.id AND u.hierarquia IN ('administrador', 'gerente')
                WHERE f.status = 'ativo' 
                AND f.aso_validade IS NOT NULL
                AND f.aso_validade BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                AND NOT EXISTS (
                    SELECT 1 FROM alertas_email ae 
                    WHERE ae.funcionario_id = f.id 
                    AND ae.tipo = 'aso' 
                    AND ae.data_vencimento = f.aso_validade 
                    AND ae.enviado = TRUE
                )";
        
        $asoAlerts = $db->fetchAll($sql);
        
        foreach ($asoAlerts as $alert) {
            $daysToExpire = (new DateTime($alert['aso_validade']))->diff(new DateTime())->days;
            
            if (in_array($daysToExpire, [30, 15])) {
                $subject = "Alerta: ASO vencendo em {$daysToExpire} dias";
                $body = "
                    <h3>Alerta de Vencimento de ASO</h3>
                    <p><strong>Funcionário:</strong> {$alert['nome']}</p>
                    <p><strong>Empresa:</strong> {$alert['empresa']}</p>
                    <p><strong>Filial:</strong> {$alert['filial']}</p>
                    <p><strong>Data de Vencimento:</strong> " . date('d/m/Y', strtotime($alert['aso_validade'])) . "</p>
                    <p><strong>Dias para vencimento:</strong> {$daysToExpire}</p>
                ";
                
                if ($alert['email'] && sendEmail($alert['email'], $subject, $body)) {
                    // Registra o alerta como enviado
                    $db->execute(
                        "INSERT INTO alertas_email (funcionario_id, tipo, data_vencimento, dias_antecedencia, enviado, data_envio, email_destinatario) 
                         VALUES (?, 'aso', ?, ?, TRUE, NOW(), ?)",
                        [$alert['id'], $alert['aso_validade'], $daysToExpire, $alert['email']]
                    );
                }
            }
        }
        
        // Alertas de Treinamentos
        $sql = "SELECT f.id, f.nome, ft.data_vencimento, t.nome as treinamento,
                       e.razao_social as empresa, fil.nome as filial, u.email
                FROM funcionarios f
                JOIN funcionario_treinamentos ft ON f.id = ft.funcionario_id
                JOIN treinamentos t ON ft.treinamento_id = t.id
                JOIN empresas e ON f.empresa_id = e.id
                JOIN filiais fil ON f.filial_id = fil.id
                LEFT JOIN usuarios u ON u.empresa_id = e.id AND u.hierarquia IN ('administrador', 'gerente')
                WHERE f.status = 'ativo' 
                AND ft.data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                AND NOT EXISTS (
                    SELECT 1 FROM alertas_email ae 
                    WHERE ae.funcionario_id = f.id 
                    AND ae.tipo = 'treinamento' 
                    AND ae.referencia_id = ft.treinamento_id
                    AND ae.data_vencimento = ft.data_vencimento 
                    AND ae.enviado = TRUE
                )";
        
        $trainingAlerts = $db->fetchAll($sql);
        
        foreach ($trainingAlerts as $alert) {
            $daysToExpire = (new DateTime($alert['data_vencimento']))->diff(new DateTime())->days;
            
            if (in_array($daysToExpire, [30, 15])) {
                $subject = "Alerta: Treinamento vencendo em {$daysToExpire} dias";
                $body = "
                    <h3>Alerta de Vencimento de Treinamento</h3>
                    <p><strong>Funcionário:</strong> {$alert['nome']}</p>
                    <p><strong>Treinamento:</strong> {$alert['treinamento']}</p>
                    <p><strong>Empresa:</strong> {$alert['empresa']}</p>
                    <p><strong>Filial:</strong> {$alert['filial']}</p>
                    <p><strong>Data de Vencimento:</strong> " . date('d/m/Y', strtotime($alert['data_vencimento'])) . "</p>
                    <p><strong>Dias para vencimento:</strong> {$daysToExpire}</p>
                ";
                
                if ($alert['email'] && sendEmail($alert['email'], $subject, $body)) {
                    // Registra o alerta como enviado
                    $db->execute(
                        "INSERT INTO alertas_email (funcionario_id, tipo, referencia_id, data_vencimento, dias_antecedencia, enviado, data_envio, email_destinatario) 
                         VALUES (?, 'treinamento', ?, ?, ?, TRUE, NOW(), ?)",
                        [$alert['id'], $alert['treinamento_id'], $alert['data_vencimento'], $daysToExpire, $alert['email']]
                    );
                }
            }
        }
        
    } catch (Exception $e) {
        error_log("Erro ao gerar alertas: " . $e->getMessage());
    }
}

/**
 * Upload de arquivo
 */
function uploadFile($file, $allowedTypes = null, $maxSize = null, $customPath = null) {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        throw new Exception('Nenhum arquivo foi enviado.');
    }
    
    $allowedTypes = $allowedTypes ?: UPLOAD_ALLOWED_TYPES;
    $maxSize = $maxSize ?: UPLOAD_MAX_SIZE;
    $uploadPath = $customPath ?: UPLOAD_PATH;
    
    // Verifica o tamanho
    if ($file['size'] > $maxSize) {
        throw new Exception('Arquivo muito grande. Tamanho máximo: ' . formatBytes($maxSize));
    }
    
    // Verifica o tipo
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($fileExtension, $allowedTypes)) {
        throw new Exception('Tipo de arquivo não permitido. Tipos aceitos: ' . implode(', ', $allowedTypes));
    }
    
    // Gera nome único
    $fileName = uniqid() . '_' . time() . '.' . $fileExtension;
    $filePath = $uploadPath . $fileName;
    
    // Cria diretório se não existir
    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0755, true);
    }
    
    // Move o arquivo
    if (!move_uploaded_file($file['tmp_name'], $filePath)) {
        throw new Exception('Erro ao salvar o arquivo.');
    }
    
    return $fileName;
}

/**
 * Formata bytes em formato legível
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}

/**
 * Gera relatório em PDF
 */
function generatePDFReport($title, $data, $headers = []) {
    require_once __DIR__ . '/../vendor/autoload.php';
    
    // Implementação básica com FPDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, $title, 0, 1, 'C');
    $pdf->Ln(10);
    
    // Cabeçalhos
    if (!empty($headers)) {
        $pdf->SetFont('Arial', 'B', 12);
        foreach ($headers as $header) {
            $pdf->Cell(40, 10, $header, 1, 0, 'C');
        }
        $pdf->Ln();
    }
    
    // Dados
    $pdf->SetFont('Arial', '', 10);
    foreach ($data as $row) {
        foreach ($row as $cell) {
            $pdf->Cell(40, 10, $cell, 1, 0, 'C');
        }
        $pdf->Ln();
    }
    
    return $pdf->Output('S'); // Retorna como string
}

/**
 * Gera relatório em Excel
 */
function generateExcelReport($title, $data, $headers = []) {
    // Implementação básica - pode ser melhorada com PhpSpreadsheet
    $output = "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>{$title}</title></head><body>";
    $output .= "<h1>{$title}</h1>";
    $output .= "<table border='1'>";
    
    if (!empty($headers)) {
        $output .= "<tr>";
        foreach ($headers as $header) {
            $output .= "<th>{$header}</th>";
        }
        $output .= "</tr>";
    }
    
    foreach ($data as $row) {
        $output .= "<tr>";
        foreach ($row as $cell) {
            $output .= "<td>{$cell}</td>";
        }
        $output .= "</tr>";
    }
    
    $output .= "</table></body></html>";
    
    return $output;
}

/**
 * Processa importação de planilha CSV
 */
function processCSVImport($filePath, $mapping = []) {
    if (!file_exists($filePath)) {
        throw new Exception('Arquivo não encontrado.');
    }
    
    $data = [];
    $handle = fopen($filePath, 'r');
    
    if ($handle === false) {
        throw new Exception('Erro ao abrir o arquivo.');
    }
    
    // Lê o cabeçalho
    $headers = fgetcsv($handle, 1000, ',');
    
    if ($headers === false) {
        fclose($handle);
        throw new Exception('Arquivo CSV inválido.');
    }
    
    // Lê os dados
    while (($row = fgetcsv($handle, 1000, ',')) !== false) {
        $rowData = [];
        
        foreach ($headers as $index => $header) {
            $mappedKey = isset($mapping[$header]) ? $mapping[$header] : $header;
            $rowData[$mappedKey] = isset($row[$index]) ? trim($row[$index]) : '';
        }
        
        $data[] = $rowData;
    }
    
    fclose($handle);
    return $data;
}

/**
 * Calcula próxima data de vencimento baseada na validade em meses
 */
function calculateExpirationDate($startDate, $validityMonths) {
    $date = new DateTime($startDate);
    $date->add(new DateInterval("P{$validityMonths}M"));
    return $date->format('Y-m-d');
}

/**
 * Verifica se funcionário está apto para trabalho
 */
function isEmployeeApt($employeeId) {
    try {
        $db = getDB();
        
        // Verifica ASO
        $employee = $db->fetch(
            "SELECT aso_validade FROM funcionarios WHERE id = ? AND status = 'ativo'",
            [$employeeId]
        );
        
        if (!$employee || !$employee['aso_validade'] || $employee['aso_validade'] < date('Y-m-d')) {
            return false;
        }
        
        // Verifica treinamentos obrigatórios
        $expiredTrainings = $db->fetch(
            "SELECT COUNT(*) as count FROM funcionario_treinamentos ft
             JOIN treinamentos t ON ft.treinamento_id = t.id
             WHERE ft.funcionario_id = ? AND t.obrigatorio = TRUE AND ft.data_vencimento < CURDATE()",
            [$employeeId]
        );
        
        return $expiredTrainings['count'] == 0;
        
    } catch (Exception $e) {
        error_log("Erro ao verificar aptidão do funcionário: " . $e->getMessage());
        return false;
    }
}

/**
 * Obtém estatísticas do dashboard
 */
function getDashboardStats() {
    try {
        $db = getDB();
        return $db->fetch("SELECT * FROM vw_dashboard_stats");
    } catch (Exception $e) {
        error_log("Erro ao obter estatísticas do dashboard: " . $e->getMessage());
        return [];
    }
}

/**
 * Formata data para exibição
 */
function formatDate($date, $format = 'd/m/Y') {
    if (empty($date) || $date === '0000-00-00') {
        return '-';
    }
    
    return date($format, strtotime($date));
}

/**
 * Calcula idade baseada na data de nascimento
 */
function calculateAge($birthDate) {
    if (empty($birthDate) || $birthDate === '0000-00-00') {
        return null;
    }
    
    $birth = new DateTime($birthDate);
    $today = new DateTime();
    return $birth->diff($today)->y;
}

/**
 * Gera senha aleatória
 */
function generateRandomPassword($length = 8) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    return substr(str_shuffle($chars), 0, $length);
}



/**
 * Exibe mensagem de sucesso ou erro
 */
function showMessage($message, $type = 'info') {
    $_SESSION['message'] = [
        'text' => $message,
        'type' => $type
    ];
}

/**
 * Obtém e limpa mensagem da sessão
 */
function getMessage() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        unset($_SESSION['message']);
        return $message;
    }
    return null;
}
?>