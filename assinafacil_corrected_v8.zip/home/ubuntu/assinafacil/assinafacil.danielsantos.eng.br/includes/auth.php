<?php
/**
 * Funções de Autenticação e Autorização
 * Sistema de Gestão de Terceiros
 */

/**
 * Verifica se sessão é válida
 */
function isValidSession() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['last_activity'])) {
        return false;
    }
    
    // Verifica timeout da sessão
    if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
        session_destroy();
        return false;
    }
    
    $_SESSION['last_activity'] = time();
    return true;
}

/**
 * Redireciona para página de login
 */
function redirectToLogin() {
    header('Location: index.php');
    exit;
}

/**
 * Verifica se o usuário está logado e tem permissão para acessar a página
 */
function requireAuth($requiredPermission = null) {
    if (!isValidSession()) {
        redirectToLogin();
    }
    
    if ($requiredPermission && !hasPermission($requiredPermission)) {
        http_response_code(403);
        showAccessDenied();
        exit;
    }
}

/**
 * Verifica se o usuário tem permissão para acessar uma empresa específica
 */
function canAccessEmpresa($empresaId) {
    $userEmpresaId = $_SESSION['user_empresa_id'] ?? null;
    $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    
    // Gerentes e administradores podem acessar todas as empresas
    if (in_array($userHierarchy, ['gerente', 'administrador'])) {
        return true;
    }
    
    // Outros usuários só podem acessar sua própria empresa
    return $userEmpresaId && $userEmpresaId == $empresaId;
}

/**
 * Verifica se o usuário tem permissão para acessar uma filial específica
 */
function canAccessFilial($filialId) {
    $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    $userFiliaisPermitidas = $_SESSION['user_filiais_permitidas'] ?? null;
    
    // Gerentes e administradores podem acessar todas as filiais
    if (in_array($userHierarchy, ['gerente', 'administrador'])) {
        return true;
    }
    
    // Verifica se a filial está na lista de filiais permitidas
    if ($userFiliaisPermitidas) {
        $filiaisArray = json_decode($userFiliaisPermitidas, true);
        return is_array($filiaisArray) && in_array($filialId, $filiaisArray);
    }
    
    return false;
}

/**
 * Obtém as empresas que o usuário pode acessar
 */
function getUserAccessibleEmpresas() {
    $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    $userEmpresaId = $_SESSION['user_empresa_id'] ?? null;
    
    try {
        $db = getDB();
        
        if (in_array($userHierarchy, ['gerente', 'administrador'])) {
            // Pode acessar todas as empresas
            return $db->fetchAll("SELECT id, razao_social FROM empresas WHERE ativo = TRUE ORDER BY razao_social");
        } else {
            // Só pode acessar sua própria empresa
            if ($userEmpresaId) {
                return $db->fetchAll(
                    "SELECT id, razao_social FROM empresas WHERE id = ? AND ativo = TRUE",
                    [$userEmpresaId]
                );
            }
        }
    } catch (Exception $e) {
        error_log("Erro ao buscar empresas acessíveis: " . $e->getMessage());
    }
    
    return [];
}

/**
 * Obtém as filiais que o usuário pode acessar
 */
function getUserAccessibleFiliais($empresaId = null) {
    $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    $userFiliaisPermitidas = $_SESSION['user_filiais_permitidas'] ?? null;
    
    try {
        $db = getDB();
        
        if (in_array($userHierarchy, ['gerente', 'administrador'])) {
            // Pode acessar todas as filiais
            $sql = "SELECT id, nome, empresa_id FROM filiais WHERE ativo = TRUE";
            $params = [];
            
            if ($empresaId) {
                $sql .= " AND empresa_id = ?";
                $params[] = $empresaId;
            }
            
            $sql .= " ORDER BY nome";
            
            return $db->fetchAll($sql, $params);
        } else {
            // Só pode acessar filiais específicas
            if ($userFiliaisPermitidas) {
                $filiaisArray = json_decode($userFiliaisPermitidas, true);
                
                if (is_array($filiaisArray) && !empty($filiaisArray)) {
                    $placeholders = str_repeat('?,', count($filiaisArray) - 1) . '?';
                    $sql = "SELECT id, nome, empresa_id FROM filiais WHERE id IN ($placeholders) AND ativo = TRUE";
                    $params = $filiaisArray;
                    
                    if ($empresaId) {
                        $sql .= " AND empresa_id = ?";
                        $params[] = $empresaId;
                    }
                    
                    $sql .= " ORDER BY nome";
                    
                    return $db->fetchAll($sql, $params);
                }
            }
        }
    } catch (Exception $e) {
        error_log("Erro ao buscar filiais acessíveis: " . $e->getMessage());
    }
    
    return [];
}

/**
 * Verifica se o usuário pode gerenciar outros usuários
 */
function canManageUsers() {
    return hasPermission('manage_users');
}

/**
 * Verifica se o usuário pode gerenciar configurações do sistema
 */
function canManageSystem() {
    return hasPermission('manage_system');
}

/**
 * Obtém o nível hierárquico do usuário
 */
function getUserHierarchyLevel() {
    $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    $hierarchies = USER_HIERARCHIES;
    
    return isset($hierarchies[$userHierarchy]) ? $hierarchies[$userHierarchy]['level'] : 1;
}

/**
 * Verifica se o usuário pode gerenciar outro usuário baseado na hierarquia
 */
function canManageUser($targetUserHierarchy) {
    if (!hasPermission('manage_users')) {
        return false;
    }
    
    $currentLevel = getUserHierarchyLevel();
    $hierarchies = USER_HIERARCHIES;
    $targetLevel = isset($hierarchies[$targetUserHierarchy]) ? $hierarchies[$targetUserHierarchy]['level'] : 1;
    
    // Só pode gerenciar usuários de nível inferior
    return $currentLevel > $targetLevel;
}

/**
 * Aplica filtros de acesso baseados nas permissões do usuário
 */
function applyAccessFilters($sql, $params = [], $tableAlias = 'f') {
    $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    $userEmpresaId = $_SESSION['user_empresa_id'] ?? null;
    $userFiliaisPermitidas = $_SESSION['user_filiais_permitidas'] ?? null;
    
    // Gerentes e administradores veem tudo
    if (in_array($userHierarchy, ['gerente', 'administrador'])) {
        return [$sql, $params];
    }
    
    // Aplicar filtros baseados na empresa
    if ($userEmpresaId) {
        $sql .= " AND {$tableAlias}.empresa_id = ?";
        $params[] = $userEmpresaId;
    }
    
    // Aplicar filtros baseados nas filiais (se aplicável)
    if ($userFiliaisPermitidas && strpos($sql, $tableAlias . '.filial_id') !== false) {
        $filiaisArray = json_decode($userFiliaisPermitidas, true);
        
        if (is_array($filiaisArray) && !empty($filiaisArray)) {
            $placeholders = str_repeat('?,', count($filiaisArray) - 1) . '?';
            $sql .= " AND {$tableAlias}.filial_id IN ($placeholders)";
            $params = array_merge($params, $filiaisArray);
        }
    }
    
    return [$sql, $params];
}

/**
 * Exibe página de acesso negado
 */
function showAccessDenied() {
    $pageTitle = 'Acesso Negado';
    include __DIR__ . '/header.php';
    ?>
    <div class="card">
        <div style="text-align: center; padding: 60px 20px;">
            <i class="fas fa-lock" style="font-size: 4rem; color: var(--danger); margin-bottom: 20px;"></i>
            <h2 style="color: var(--danger); margin-bottom: 15px;">Acesso Negado</h2>
            <p style="color: var(--gray); margin-bottom: 30px;">
                Você não tem permissão para acessar esta página ou realizar esta ação.
            </p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="dashboard.php" class="btn btn-primary">
                    <i class="fas fa-home"></i>
                    Voltar ao Dashboard
                </a>
                <button onclick="history.back()" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i>
                    Voltar
                </button>
            </div>
        </div>
    </div>
    <?php
    include __DIR__ . '/footer.php';
}

/**
 * Middleware para verificar permissões em APIs
 */
function checkAPIPermission($requiredPermission) {
    if (!isValidSession()) {
        http_response_code(401);
        echo json_encode(['error' => 'Não autorizado']);
        exit;
    }
    
    if ($requiredPermission && !hasPermission($requiredPermission)) {
        http_response_code(403);
        echo json_encode(['error' => 'Sem permissão para esta ação']);
        exit;
    }
}

/**
 * Obtém informações do usuário logado
 */
function getCurrentUser() {
    if (!isValidSession()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'name' => $_SESSION['user_name'] ?? null,
        'email' => $_SESSION['user_email'] ?? null,
        'hierarchy' => $_SESSION['user_hierarchy'] ?? 'visualizador',
        'empresa_id' => $_SESSION['user_empresa_id'] ?? null,
        'filiais_permitidas' => $_SESSION['user_filiais_permitidas'] ?? null,
        'level' => getUserHierarchyLevel()
    ];
}

/**
 * Registra tentativa de acesso não autorizado
 */
function logUnauthorizedAccess($resource, $action = 'access') {
    try {
        $user = getCurrentUser();
        $userId = $user ? $user['id'] : 0;
        
        logAuditoria('security', 0, 'unauthorized_access', null, [
            'user_id' => $userId,
            'resource' => $resource,
            'action' => $action,
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? ''
        ]);
    } catch (Exception $e) {
        error_log("Erro ao registrar acesso não autorizado: " . $e->getMessage());
    }
}

/**
 * Verifica se o usuário pode acessar dados de um funcionário específico
 */
function canAccessFuncionario($funcionarioId) {
    try {
        $db = getDB();
        $funcionario = $db->fetch(
            "SELECT empresa_id, filial_id FROM funcionarios WHERE id = ?",
            [$funcionarioId]
        );
        
        if (!$funcionario) {
            return false;
        }
        
        return canAccessEmpresa($funcionario['empresa_id']) && 
               canAccessFilial($funcionario['filial_id']);
    } catch (Exception $e) {
        error_log("Erro ao verificar acesso ao funcionário: " . $e->getMessage());
        return false;
    }
}

/**
 * Middleware para páginas que requerem autenticação
 */
function requireLogin() {
    if (!isValidSession()) {
        // Se for uma requisição AJAX, retorna JSON
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            http_response_code(401);
            echo json_encode(['error' => 'Sessão expirada. Faça login novamente.']);
            exit;
        }
        
        // Redireciona para login
        redirectToLogin();
    }
}

/**
 * Obtém permissões do usuário em formato array
 */
function getUserPermissions() {
    $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    $hierarchies = USER_HIERARCHIES;
    
    return isset($hierarchies[$userHierarchy]) ? $hierarchies[$userHierarchy]['permissions'] : [];
}

/**
 * Verifica múltiplas permissões de uma vez
 */
function hasAnyPermission($permissions) {
    if (!is_array($permissions)) {
        $permissions = [$permissions];
    }
    
    foreach ($permissions as $permission) {
        if (hasPermission($permission)) {
            return true;
        }
    }
    
    return false;
}

/**
 * Verifica se o usuário tem todas as permissões especificadas
 */
function hasAllPermissions($permissions) {
    if (!is_array($permissions)) {
        $permissions = [$permissions];
    }
    
    foreach ($permissions as $permission) {
        if (!hasPermission($permission)) {
            return false;
        }
    }
    
    return true;
}
?>
