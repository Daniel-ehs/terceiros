<?php
/**
 * Logout
 * Sistema de Gestão de Terceiros
 */

require_once 'config/config.php';
require_once 'includes/functions.php';

// Log de auditoria se o usuário estiver logado
if (isset($_SESSION['user_id'])) {
    try {
        logAuditoria('usuarios', $_SESSION['user_id'], 'logout', null, ['timestamp' => date('Y-m-d H:i:s')]);
    } catch (Exception $e) {
        // Silencioso em caso de erro
    }
}

// Destruir sessão
session_destroy();

// Redirecionar para login
header('Location: index.php');
exit;
?>
