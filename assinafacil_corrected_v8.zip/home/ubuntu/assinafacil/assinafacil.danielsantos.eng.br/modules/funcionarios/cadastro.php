<?php
/**
 * Cadastro/Edição de Funcionários
 * Sistema de Gestão de Terceiros
 */

require_once '../../config/config.php';

// Verificar permissões
$isEdit = isset($_GET['id']) && !empty($_GET['id']);
$requiredPermission = $isEdit ? 'update' : 'create';
requireAuth($requiredPermission);

$funcionarioId = $isEdit ? (int)$_GET['id'] : null;
$funcionario = null;
$treinamentos = [];

$pageTitle = $isEdit ? 'Editar Funcionário' : 'Novo Funcionário';
$breadcrumb = [
    ['title' => 'Funcionários', 'url' => '/gestao_terceiros/modules/funcionarios/'],
    ['title' => $isEdit ? 'Editar' : 'Novo']
];

// Buscar dados para edição
if ($isEdit) {
    try {
        $db = getDB();
        
        // Verificar se pode acessar este funcionário
        if (!canAccessFuncionario($funcionarioId)) {
            logUnauthorizedAccess("funcionario_$funcionarioId", 'edit');
            showAccessDenied();
            exit;
        }
        
        $funcionario = $db->fetch(
            "SELECT * FROM funcionarios WHERE id = ?",
            [$funcionarioId]
        );
        
        if (!$funcionario) {
            showMessage('Funcionário não encontrado', 'danger');
            header('Location: index.php');
            exit;
        }
        
        // Buscar treinamentos do funcionário
        $treinamentos = $db->fetchAll(
            "SELECT ft.*, t.nome as treinamento_nome 
             FROM funcionario_treinamentos ft
             JOIN treinamentos t ON ft.treinamento_id = t.id
             WHERE ft.funcionario_id = ?
             ORDER BY ft.data_vencimento",
            [$funcionarioId]
        );
        
    } catch (Exception $e) {
        error_log("Erro ao buscar funcionário: " . $e->getMessage());
        showMessage('Erro ao carregar dados do funcionário', 'danger');
        header('Location: index.php');
        exit;
    }
}

// Buscar empresas e filiais acessíveis
$empresas = getUserAccessibleEmpresas();
$filiais = getUserAccessibleFiliais();

// Buscar todos os treinamentos disponíveis
try {
    $db = getDB();
    $todosOsTreinamentos = $db->fetchAll(
        "SELECT id, nome, validade_meses, obrigatorio FROM treinamentos WHERE ativo = TRUE ORDER BY nome"
    );
} catch (Exception $e) {
    $todosOsTreinamentos = [];
}

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'nome' => sanitizeInput($_POST['nome'] ?? ''),
        'cpf' => preg_replace('/[^0-9]/', '', $_POST['cpf'] ?? ''),
        'matricula' => sanitizeInput($_POST['matricula'] ?? ''),
        'empresa_id' => (int)($_POST['empresa_id'] ?? 0),
        'filial_id' => (int)($_POST['filial_id'] ?? 0),
        'aso_data' => $_POST['aso_data'] ?? null,
        'status' => $_POST['status'] ?? 'ativo',
        'observacoes' => sanitizeInput($_POST['observacoes'] ?? '')
    ];
    
    $errors = [];
    
    // Validações
    if (empty($data['nome'])) {
        $errors[] = 'Nome é obrigatório';
    }
    
    if (empty($data['cpf']) || !validateCPF($data['cpf'])) {
        $errors[] = 'CPF inválido';
    }
    
    if (!$data['empresa_id'] || !canAccessEmpresa($data['empresa_id'])) {
        $errors[] = 'Empresa inválida ou sem permissão de acesso';
    }
    
    if (!$data['filial_id'] || !canAccessFilial($data['filial_id'])) {
        $errors[] = 'Filial inválida ou sem permissão de acesso';
    }
    
    // Verificar CPF duplicado
    if (!empty($data['cpf'])) {
        $cpfExists = $db->fetch(
            "SELECT id FROM funcionarios WHERE cpf = ?" . ($isEdit ? " AND id != ?" : ""),
            $isEdit ? [$data['cpf'], $funcionarioId] : [$data['cpf']]
        );
        
        if ($cpfExists) {
            $errors[] = 'CPF já cadastrado para outro funcionário';
        }
    }
    
    if (empty($errors)) {
        try {
            $db->beginTransaction();
            
            // Calcular validade do ASO
            $asoValidade = null;
            if ($data['aso_data']) {
                $asoValidade = calculateExpirationDate($data['aso_data'], 12);
            }
            
            if ($isEdit) {
                // Atualizar funcionário
                $dadosAnteriores = $funcionario;
                
                $sql = "UPDATE funcionarios SET 
                        nome = ?, cpf = ?, matricula = ?, empresa_id = ?, filial_id = ?, 
                        aso_data = ?, aso_validade = ?, status = ?, observacoes = ?, 
                        atualizado_em = NOW() 
                        WHERE id = ?";
                
                $params = [
                    $data['nome'], $data['cpf'], $data['matricula'], 
                    $data['empresa_id'], $data['filial_id'],
                    $data['aso_data'], $asoValidade, $data['status'], $data['observacoes'],
                    $funcionarioId
                ];
                
                $db->execute($sql, $params);
                
                // Log auditoria
                logAuditoria('funcionarios', $funcionarioId, 'update', $dadosAnteriores, $data);
                
                $message = 'Funcionário atualizado com sucesso';
                
            } else {
                // Criar funcionário
                $sql = "INSERT INTO funcionarios (nome, cpf, matricula, empresa_id, filial_id, aso_data, aso_validade, status, observacoes) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $params = [
                    $data['nome'], $data['cpf'], $data['matricula'], 
                    $data['empresa_id'], $data['filial_id'],
                    $data['aso_data'], $asoValidade, $data['status'], $data['observacoes']
                ];
                
                $db->execute($sql, $params);
                $funcionarioId = $db->lastInsertId();
                
                // Log auditoria
                logAuditoria('funcionarios', $funcionarioId, 'create', null, $data);
                
                $message = 'Funcionário cadastrado com sucesso';
            }
            
            // Processar treinamentos
            if (isset($_POST['treinamentos']) && is_array($_POST['treinamentos'])) {
                // Remover treinamentos existentes se for edição
                if ($isEdit) {
                    $db->execute("DELETE FROM funcionario_treinamentos WHERE funcionario_id = ?", [$funcionarioId]);
                }
                
                // Inserir novos treinamentos
                foreach ($_POST['treinamentos'] as $treinamento) {
                    if (!empty($treinamento['treinamento_id']) && !empty($treinamento['data_realizacao'])) {
                        $treinamentoData = $db->fetch(
                            "SELECT validade_meses FROM treinamentos WHERE id = ?",
                            [$treinamento['treinamento_id']]
                        );
                        
                        if ($treinamentoData) {
                            $dataVencimento = calculateExpirationDate(
                                $treinamento['data_realizacao'], 
                                $treinamentoData['validade_meses']
                            );
                            
                            $db->execute(
                                "INSERT INTO funcionario_treinamentos (funcionario_id, treinamento_id, data_realizacao, data_vencimento, observacoes) 
                                 VALUES (?, ?, ?, ?, ?)",
                                [
                                    $funcionarioId,
                                    $treinamento['treinamento_id'],
                                    $treinamento['data_realizacao'],
                                    $dataVencimento,
                                    $treinamento['observacoes'] ?? null
                                ]
                            );
                        }
                    }
                }
            }
            
            $db->commit();
            
            showMessage($message, 'success');
            header('Location: index.php');
            exit;
            
        } catch (Exception $e) {
            $db->rollback();
            error_log("Erro ao salvar funcionário: " . $e->getMessage());
            $errors[] = 'Erro interno. Tente novamente.';
        }
    }
    
    if (!empty($errors)) {
        showMessage(implode('<br>', $errors), 'danger');
    }
}

include '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">
            <i class="fas fa-<?php echo $isEdit ? 'edit' : 'plus'; ?>"></i>
            <?php echo $pageTitle; ?>
        </h2>
        <div class="card-actions">
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i>
                Voltar
            </a>
        </div>
    </div>
    
    <form method="POST" id="funcionario-form" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
        
        <!-- Dados Pessoais -->
        <fieldset style="border: 2px solid var(--light-green); border-radius: var(--border-radius); padding: 20px; margin-bottom: 25px;">
            <legend style="color: var(--primary-green); font-weight: 600; padding: 0 10px;">Dados Pessoais</legend>
            
            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div class="form-group">
                    <label for="nome" class="form-label">Nome Completo *</label>
                    <input 
                        type="text" 
                        id="nome" 
                        name="nome" 
                        class="form-control" 
                        value="<?php echo htmlspecialchars($funcionario['nome'] ?? ''); ?>"
                        required
                        maxlength="255"
                    >
                </div>
                
                <div class="form-group">
                    <label for="cpf" class="form-label">CPF *</label>
                    <input 
                        type="text" 
                        id="cpf" 
                        name="cpf" 
                        class="form-control" 
                        data-mask="cpf"
                        data-type="cpf"
                        value="<?php echo $funcionario ? formatCPF($funcionario['cpf']) : ''; ?>"
                        required
                        maxlength="14"
                    >
                </div>
                
                <div class="form-group">
                    <label for="matricula" class="form-label">Matrícula</label>
                    <input 
                        type="text" 
                        id="matricula" 
                        name="matricula" 
                        class="form-control" 
                        value="<?php echo htmlspecialchars($funcionario['matricula'] ?? ''); ?>"
                        maxlength="50"
                    >
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label for="empresa_id" class="form-label">Empresa *</label>
                    <select id="empresa_id" name="empresa_id" class="form-control" required>
                        <option value="">Selecione uma empresa</option>
                        <?php foreach ($empresas as $empresa): ?>
                        <option value="<?php echo $empresa['id']; ?>" 
                                <?php echo ($funcionario && $funcionario['empresa_id'] == $empresa['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($empresa['razao_social']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="filial_id" class="form-label">Filial *</label>
                    <select id="filial_id" name="filial_id" class="form-control" required>
                        <option value="">Selecione uma filial</option>
                        <?php foreach ($filiais as $filial): ?>
                        <option value="<?php echo $filial['id']; ?>" 
                                data-empresa="<?php echo $filial['empresa_id']; ?>"
                                <?php echo ($funcionario && $funcionario['filial_id'] == $filial['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($filial['nome']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-control">
                        <?php foreach (EMPLOYEE_STATUS as $value => $label): ?>
                        <option value="<?php echo $value; ?>" 
                                <?php echo ($funcionario && $funcionario['status'] == $value) ? 'selected' : ($value == 'ativo' ? 'selected' : ''); ?>>
                            <?php echo $label; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </fieldset>
        
        <!-- ASO -->
        <fieldset style="border: 2px solid var(--light-green); border-radius: var(--border-radius); padding: 20px; margin-bottom: 25px;">
            <legend style="color: var(--primary-green); font-weight: 600; padding: 0 10px;">ASO (Atestado de Saúde Ocupacional)</legend>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label for="aso_data" class="form-label">Data do ASO</label>
                    <input 
                        type="date" 
                        id="aso_data" 
                        name="aso_data" 
                        class="form-control" 
                        value="<?php echo $funcionario['aso_data'] ?? ''; ?>"
                    >
                </div>
                
                <div class="form-group">
                    <label class="form-label">Validade do ASO</label>
                    <input 
                        type="text" 
                        id="aso_validade" 
                        class="form-control" 
                        value="<?php echo $funcionario ? formatDate($funcionario['aso_validade']) : ''; ?>"
                        readonly
                        style="background: var(--light-gray);"
                        placeholder="Calculado automaticamente"
                    >
                    <small style="color: var(--gray);">Validade calculada automaticamente (12 meses após a data do ASO)</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Status do ASO</label>
                    <div id="aso-status" style="padding: 10px;">
                        <span class="status-badge status-sem-documento">Sem ASO</span>
                    </div>
                </div>
            </div>
        </fieldset>
        
        <!-- Treinamentos -->
        <fieldset style="border: 2px solid var(--light-green); border-radius: var(--border-radius); padding: 20px; margin-bottom: 25px;">
            <legend style="color: var(--primary-green); font-weight: 600; padding: 0 10px;">Treinamentos</legend>
            
            <div style="margin-bottom: 15px;">
                <button type="button" onclick="addTreinamento()" class="btn btn-outline btn-sm">
                    <i class="fas fa-plus"></i>
                    Adicionar Treinamento
                </button>
            </div>
            
            <div id="treinamentos-container">
                <?php if (!empty($treinamentos)): ?>
                    <?php foreach ($treinamentos as $index => $treinamento): ?>
                    <div class="treinamento-item" style="border: 1px solid var(--light-green); border-radius: var(--border-radius); padding: 15px; margin-bottom: 15px;">
                        <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 15px; align-items: end;">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label class="form-label">Treinamento</label>
                                <select name="treinamentos[<?php echo $index; ?>][treinamento_id]" class="form-control treinamento-select">
                                    <option value="">Selecione um treinamento</option>
                                    <?php foreach ($todosOsTreinamentos as $t): ?>
                                    <option value="<?php echo $t['id']; ?>" 
                                            data-validade="<?php echo $t['validade_meses']; ?>"
                                            <?php echo ($t['id'] == $treinamento['treinamento_id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($t['nome']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 0;">
                                <label class="form-label">Data de Realização</label>
                                <input 
                                    type="date" 
                                    name="treinamentos[<?php echo $index; ?>][data_realizacao]" 
                                    class="form-control data-realizacao"
                                    value="<?php echo $treinamento['data_realizacao']; ?>"
                                >
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 0;">
                                <label class="form-label">Data de Vencimento</label>
                                <input 
                                    type="text" 
                                    class="form-control data-vencimento" 
                                    value="<?php echo formatDate($treinamento['data_vencimento']); ?>"
                                    readonly
                                    style="background: var(--light-gray);"
                                >
                            </div>
                            
                            <button type="button" onclick="removeTreinamento(this)" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        
                        <div class="form-group" style="margin-top: 15px; margin-bottom: 0;">
                            <label class="form-label">Observações</label>
                            <textarea 
                                name="treinamentos[<?php echo $index; ?>][observacoes]" 
                                class="form-control" 
                                rows="2"
                                placeholder="Observações sobre o treinamento..."
                            ><?php echo htmlspecialchars($treinamento['observacoes'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </fieldset>
        
        <!-- Observações -->
        <fieldset style="border: 2px solid var(--light-green); border-radius: var(--border-radius); padding: 20px; margin-bottom: 25px;">
            <legend style="color: var(--primary-green); font-weight: 600; padding: 0 10px;">Observações</legend>
            
            <div class="form-group">
                <textarea 
                    id="observacoes" 
                    name="observacoes" 
                    class="form-control" 
                    rows="4"
                    placeholder="Observações gerais sobre o funcionário..."
                ><?php echo htmlspecialchars($funcionario['observacoes'] ?? ''); ?></textarea>
            </div>
        </fieldset>
        
        <!-- Botões -->
        <div style="display: flex; gap: 15px; justify-content: flex-end; padding-top: 20px; border-top: 1px solid var(--light-green);">
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i>
                Cancelar
            </a>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i>
                <?php echo $isEdit ? 'Atualizar' : 'Cadastrar'; ?>
            </button>
        </div>
    </form>
</div>

<script>
let treinamentoIndex = <?php echo count($treinamentos); ?>;

// Filtrar filiais baseado na empresa selecionada
document.getElementById('empresa_id').addEventListener('change', function() {
    const empresaId = this.value;
    const filialSelect = document.getElementById('filial_id');
    const options = filialSelect.querySelectorAll('option[data-empresa]');
    
    // Reset filial
    filialSelect.value = '';
    
    options.forEach(option => {
        if (!empresaId || option.dataset.empresa === empresaId) {
            option.style.display = 'block';
        } else {
            option.style.display = 'none';
        }
    });
});

// Calcular validade do ASO
document.getElementById('aso_data').addEventListener('change', function() {
    const asoData = this.value;
    const asoValidadeInput = document.getElementById('aso_validade');
    const asoStatusDiv = document.getElementById('aso-status');
    
    if (asoData) {
        const dataASO = new Date(asoData);
        const dataValidade = new Date(dataASO);
        dataValidade.setFullYear(dataValidade.getFullYear() + 1);
        
        asoValidadeInput.value = dataValidade.toLocaleDateString('pt-BR');
        
        // Calcular status
        const hoje = new Date();
        const diffTime = dataValidade - hoje;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        let statusClass = 'status-valido';
        let statusText = 'Válido';
        
        if (diffDays < 0) {
            statusClass = 'status-vencido';
            statusText = 'Vencido';
        } else if (diffDays <= 15) {
            statusClass = 'status-vence-15-dias';
            statusText = 'Vence em ' + diffDays + ' dias';
        } else if (diffDays <= 30) {
            statusClass = 'status-vence-30-dias';
            statusText = 'Vence em ' + diffDays + ' dias';
        }
        
        asoStatusDiv.innerHTML = `<span class="status-badge ${statusClass}">${statusText}</span>`;
    } else {
        asoValidadeInput.value = '';
        asoStatusDiv.innerHTML = '<span class="status-badge status-sem-documento">Sem ASO</span>';
    }
});

// Adicionar treinamento
function addTreinamento() {
    const container = document.getElementById('treinamentos-container');
    const div = document.createElement('div');
    div.className = 'treinamento-item';
    div.style.cssText = 'border: 1px solid var(--light-green); border-radius: var(--border-radius); padding: 15px; margin-bottom: 15px;';
    
    div.innerHTML = `
        <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 15px; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Treinamento</label>
                <select name="treinamentos[${treinamentoIndex}][treinamento_id]" class="form-control treinamento-select">
                    <option value="">Selecione um treinamento</option>
                    <?php foreach ($todosOsTreinamentos as $t): ?>
                    <option value="<?php echo $t['id']; ?>" data-validade="<?php echo $t['validade_meses']; ?>">
                        <?php echo htmlspecialchars($t['nome']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Data de Realização</label>
                <input type="date" name="treinamentos[${treinamentoIndex}][data_realizacao]" class="form-control data-realizacao">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Data de Vencimento</label>
                <input type="text" class="form-control data-vencimento" readonly style="background: var(--light-gray);">
            </div>
            
            <button type="button" onclick="removeTreinamento(this)" class="btn btn-danger btn-sm">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        
        <div class="form-group" style="margin-top: 15px; margin-bottom: 0;">
            <label class="form-label">Observações</label>
            <textarea name="treinamentos[${treinamentoIndex}][observacoes]" class="form-control" rows="2" placeholder="Observações sobre o treinamento..."></textarea>
        </div>
    `;
    
    container.appendChild(div);
    
    // Adicionar eventos
    setupTreinamentoEvents(div);
    
    treinamentoIndex++;
}

// Remover treinamento
function removeTreinamento(button) {
    button.closest('.treinamento-item').remove();
}

// Configurar eventos de treinamento
function setupTreinamentoEvents(container) {
    const select = container.querySelector('.treinamento-select');
    const dataRealizacao = container.querySelector('.data-realizacao');
    const dataVencimento = container.querySelector('.data-vencimento');
    
    function calcularVencimento() {
        const treinamentoId = select.value;
        const dataReal = dataRealizacao.value;
        
        if (treinamentoId && dataReal) {
            const option = select.querySelector(`option[value="${treinamentoId}"]`);
            const validadeMeses = parseInt(option.dataset.validade);
            
            const data = new Date(dataReal);
            data.setMonth(data.getMonth() + validadeMeses);
            
            dataVencimento.value = data.toLocaleDateString('pt-BR');
        } else {
            dataVencimento.value = '';
        }
    }
    
    select.addEventListener('change', calcularVencimento);
    dataRealizacao.addEventListener('change', calcularVencimento);
}

// Configurar eventos para treinamentos existentes
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.treinamento-item').forEach(setupTreinamentoEvents);
    
    // Trigger inicial para ASO
    document.getElementById('aso_data').dispatchEvent(new Event('change'));
    
    // Trigger inicial para empresa/filial
    document.getElementById('empresa_id').dispatchEvent(new Event('change'));
    
    // Validação do formulário
    document.getElementById('funcionario-form').addEventListener('submit', function(e) {
        if (!FormManager.validate(this)) {
            e.preventDefault();
        }
    });
});
</script>

<?php include '../../includes/footer.php'; ?>

