<?php
/**
 * Lista de Funcionários
 * Sistema de Gestão de Terceiros
 */

require_once '../../config/config.php';

$pageTitle = 'Funcionários';
$breadcrumb = [
    ['title' => 'Funcionários']
];

// Buscar empresas e filiais para filtros
try {
    $db = getDB();
    $empresas = $db->fetchAll("SELECT id, razao_social FROM empresas WHERE ativo = TRUE ORDER BY razao_social");
    $filiais = $db->fetchAll("SELECT id, nome, empresa_id FROM filiais WHERE ativo = TRUE ORDER BY nome");
} catch (Exception $e) {
    $empresas = [];
    $filiais = [];
}

$additionalJS = ['/gestao_terceiros/assets/js/funcionarios.js'];

include '../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">
            <i class="fas fa-users"></i>
            Funcionários
        </h2>
        <div class="card-actions">
            <?php if (hasPermission('create')): ?>
            <a href="cadastro.php" class="btn btn-primary">
                <i class="fas fa-plus"></i>
                Novo Funcionário
            </a>
            <button onclick="Modal.show('modal-import')" class="btn btn-outline">
                <i class="fas fa-upload"></i>
                Importar CSV
            </button>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Filtros -->
    <div style="background: var(--very-light-green); padding: 20px; border-radius: var(--border-radius); margin-bottom: 20px;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Buscar</label>
                <input type="text" id="search" class="form-control" placeholder="Nome, CPF ou matrícula...">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Empresa</label>
                <select id="filter-empresa" class="form-control">
                    <option value="">Todas as empresas</option>
                    <?php foreach ($empresas as $empresa): ?>
                    <option value="<?php echo $empresa['id']; ?>"><?php echo htmlspecialchars($empresa['razao_social']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Filial</label>
                <select id="filter-filial" class="form-control">
                    <option value="">Todas as filiais</option>
                    <?php foreach ($filiais as $filial): ?>
                    <option value="<?php echo $filial['id']; ?>" data-empresa="<?php echo $filial['empresa_id']; ?>">
                        <?php echo htmlspecialchars($filial['nome']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Status</label>
                <select id="filter-status" class="form-control">
                    <option value="">Todos os status</option>
                    <option value="ativo">Ativo</option>
                    <option value="inativo">Inativo</option>
                    <option value="afastado">Afastado</option>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px;">
                <button onclick="applyFilters()" class="btn btn-primary">
                    <i class="fas fa-search"></i>
                    Filtrar
                </button>
                <button onclick="clearFilters()" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Limpar
                </button>
            </div>
        </div>
    </div>
    
    <!-- Tabela -->
    <div class="table-responsive">
        <table class="table" id="funcionarios-table">
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Funcionário</th>
                    <th>Empresa</th>
                    <th>Filial</th>
                    <th>ASO</th>
                    <th>Treinamentos</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody id="funcionarios-tbody">
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        <i class="loading"></i> Carregando funcionários...
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <!-- Paginação -->
    <div id="pagination-container" class="pagination"></div>
</div>

<!-- Modal de Importação CSV -->
<div id="modal-import" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">Importar Funcionários via CSV</h5>
            <button type="button" class="modal-close" onclick="Modal.hide('modal-import')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                <strong>Formato do arquivo CSV:</strong><br>
                Nome, CPF, Matrícula, Empresa, Filial, Data ASO, Status, Observações
            </div>
            
            <form id="import-form" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="form-label">Arquivo CSV</label>
                    <input type="file" id="csv-file" name="csv_file" class="form-control" accept=".csv,.txt" required>
                </div>
                
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="skip-duplicates" checked>
                        Pular registros com CPF duplicado
                    </label>
                </div>
            </form>
            
            <div id="import-progress" style="display: none;">
                <div style="background: var(--light-gray); border-radius: var(--border-radius); padding: 10px; margin: 10px 0;">
                    <div id="progress-bar" style="background: var(--primary-green); height: 20px; border-radius: var(--border-radius); width: 0%; transition: width 0.3s ease;"></div>
                </div>
                <div id="import-status">Preparando importação...</div>
            </div>
            
            <div id="import-results" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" onclick="startImport()" id="import-btn">
                <i class="fas fa-upload"></i>
                Importar
            </button>
            <button type="button" class="btn btn-secondary" onclick="Modal.hide('modal-import')">Cancelar</button>
        </div>
    </div>
</div>

<script>
// Variáveis globais
let currentPage = 1;
let currentFilters = {};

// Carregar funcionários
async function loadFuncionarios(page = 1, filters = {}) {
    try {
        const params = {
            page: page,
            limit: 20,
            ...filters
        };
        
        const response = await API.funcionarios.list(params);
        renderFuncionarios(response.data);
        renderPagination(response);
        
        currentPage = page;
        currentFilters = filters;
        
    } catch (error) {
        console.error('Erro ao carregar funcionários:', error);
        Utils.showToast('Erro ao carregar funcionários', 'danger');
    }
}

// Renderizar tabela de funcionários
function renderFuncionarios(funcionarios) {
    const tbody = document.getElementById('funcionarios-tbody');
    
    if (funcionarios.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 40px;">
                    <i class="fas fa-users" style="font-size: 3rem; color: var(--gray); margin-bottom: 10px;"></i><br>
                    Nenhum funcionário encontrado
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = funcionarios.map(func => `
        <tr>
            <td>
                <div class="status-indicator status-${func.status_geral || 'valido'}"></div>
            </td>
            <td>
                <div style="display: flex; align-items: center; gap: 10px;">
                    ${func.foto ? `<img src="/gestao_terceiros/assets/img/uploads/${func.foto}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">` : `<div style="width: 40px; height: 40px; border-radius: 50%; background: var(--primary-green); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">${func.nome.charAt(0)}</div>`}
                    <div>
                        <strong>${func.nome}</strong><br>
                        <small style="color: var(--gray);">${Utils.formatCPF(func.cpf)}</small>
                        ${func.matricula ? `<br><small style="color: var(--gray);">Mat: ${func.matricula}</small>` : ''}
                    </div>
                </div>
            </td>
            <td>${func.empresa_nome}</td>
            <td>${func.filial_nome}</td>
            <td>
                <span class="status-badge status-${func.status_aso}">
                    ${func.aso_validade ? Utils.formatDate(func.aso_validade) : 'Sem ASO'}
                </span>
            </td>
            <td>
                ${func.treinamentos_vencidos > 0 ? 
                    `<span class="status-badge status-vencido">${func.treinamentos_vencidos} vencido(s)</span>` :
                    `<span class="status-badge status-valido">Em dia</span>`
                }
            </td>
            <td>
                <div style="display: flex; gap: 5px;">
                    <a href="visualizar.php?id=${func.id}" class="btn btn-sm btn-outline" title="Visualizar">
                        <i class="fas fa-eye"></i>
                    </a>
                    ${hasPermission('update') ? `
                    <a href="cadastro.php?id=${func.id}" class="btn btn-sm btn-primary" title="Editar">
                        <i class="fas fa-edit"></i>
                    </a>
                    ` : ''}
                    ${hasPermission('delete') ? `
                    <button onclick="deleteFuncionario(${func.id}, '${func.nome}')" class="btn btn-sm btn-danger" title="Excluir">
                        <i class="fas fa-trash"></i>
                    </button>
                    ` : ''}
                </div>
            </td>
        </tr>
    `).join('');
}

// Renderizar paginação
function renderPagination(response) {
    const container = document.getElementById('pagination-container');
    
    if (response.pages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let html = '';
    
    // Botão anterior
    if (response.page > 1) {
        html += `<a href="#" onclick="loadFuncionarios(${response.page - 1}, currentFilters)">« Anterior</a>`;
    }
    
    // Páginas
    for (let i = 1; i <= response.pages; i++) {
        if (i === response.page) {
            html += `<span class="current">${i}</span>`;
        } else {
            html += `<a href="#" onclick="loadFuncionarios(${i}, currentFilters)">${i}</a>`;
        }
    }
    
    // Botão próximo
    if (response.page < response.pages) {
        html += `<a href="#" onclick="loadFuncionarios(${response.page + 1}, currentFilters)">Próximo »</a>`;
    }
    
    container.innerHTML = html;
}

// Aplicar filtros
function applyFilters() {
    const filters = {
        search: document.getElementById('search').value,
        empresa_id: document.getElementById('filter-empresa').value,
        filial_id: document.getElementById('filter-filial').value,
        status: document.getElementById('filter-status').value
    };
    
    // Remove filtros vazios
    Object.keys(filters).forEach(key => {
        if (!filters[key]) delete filters[key];
    });
    
    loadFuncionarios(1, filters);
}

// Limpar filtros
function clearFilters() {
    document.getElementById('search').value = '';
    document.getElementById('filter-empresa').value = '';
    document.getElementById('filter-filial').value = '';
    document.getElementById('filter-status').value = '';
    
    loadFuncionarios(1, {});
}

// Excluir funcionário
async function deleteFuncionario(id, nome) {
    if (!confirm(`Tem certeza que deseja excluir o funcionário "${nome}"?`)) {
        return;
    }
    
    try {
        await API.funcionarios.delete(id);
        Utils.showToast('Funcionário excluído com sucesso', 'success');
        loadFuncionarios(currentPage, currentFilters);
    } catch (error) {
        Utils.showToast('Erro ao excluir funcionário: ' + error.message, 'danger');
    }
}

// Importação CSV
async function startImport() {
    const fileInput = document.getElementById('csv-file');
    const file = fileInput.files[0];
    
    if (!file) {
        Utils.showToast('Selecione um arquivo CSV', 'warning');
        return;
    }
    
    const importBtn = document.getElementById('import-btn');
    const progressDiv = document.getElementById('import-progress');
    const resultsDiv = document.getElementById('import-results');
    
    // Mostrar progresso
    progressDiv.style.display = 'block';
    resultsDiv.style.display = 'none';
    importBtn.disabled = true;
    
    try {
        const response = await API.upload.importCSV(file, 'funcionarios');
        
        // Mostrar resultados
        progressDiv.style.display = 'none';
        resultsDiv.style.display = 'block';
        
        let html = `
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <strong>Importação concluída!</strong><br>
                ${response.imported} funcionário(s) importado(s) com sucesso.
            </div>
        `;
        
        if (response.errors && response.errors.length > 0) {
            html += `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Erros encontrados:</strong>
                    <ul style="margin: 10px 0 0 20px;">
                        ${response.errors.slice(0, 10).map(error => `<li>${error}</li>`).join('')}
                        ${response.errors.length > 10 ? `<li>... e mais ${response.errors.length - 10} erro(s)</li>` : ''}
                    </ul>
                </div>
            `;
        }
        
        resultsDiv.innerHTML = html;
        
        // Recarregar lista
        loadFuncionarios(currentPage, currentFilters);
        
    } catch (error) {
        progressDiv.style.display = 'none';
        resultsDiv.style.display = 'block';
        resultsDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <strong>Erro na importação:</strong><br>
                ${error.message}
            </div>
        `;
    } finally {
        importBtn.disabled = false;
    }
}

// Filtro de filiais baseado na empresa
document.getElementById('filter-empresa').addEventListener('change', function() {
    const empresaId = this.value;
    const filialSelect = document.getElementById('filter-filial');
    const options = filialSelect.querySelectorAll('option[data-empresa]');
    
    options.forEach(option => {
        if (!empresaId || option.dataset.empresa === empresaId) {
            option.style.display = 'block';
        } else {
            option.style.display = 'none';
        }
    });
    
    // Reset filial se não for da empresa selecionada
    if (empresaId && filialSelect.value) {
        const selectedOption = filialSelect.querySelector(`option[value="${filialSelect.value}"]`);
        if (selectedOption && selectedOption.dataset.empresa !== empresaId) {
            filialSelect.value = '';
        }
    }
});

// Busca em tempo real
document.getElementById('search').addEventListener('input', Utils.debounce(function() {
    applyFilters();
}, 500));

// Verificar permissões
function hasPermission(permission) {
    // Esta função seria implementada baseada nas permissões do usuário
    return true; // Simplificado para este exemplo
}

// Carregar dados iniciais
document.addEventListener('DOMContentLoaded', function() {
    loadFuncionarios();
});
</script>

<?php include '../../includes/footer.php'; ?>

