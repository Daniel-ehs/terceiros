-- =====================================================
-- Sistema de Gestão de Terceiros
-- Script de Criação do Banco de Dados
-- =====================================================

-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS gestao_terceiros CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestao_terceiros;

-- =====================================================
-- TABELA: empresas
-- =====================================================
CREATE TABLE IF NOT EXISTS empresas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    razao_social VARCHAR(255) NOT NULL,
    cnpj VARCHAR(18) NULL,
    endereco TEXT NULL,
    telefone VARCHAR(20) NULL,
    email VARCHAR(255) NULL,
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_cnpj (cnpj),
    INDEX idx_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: filiais
-- =====================================================
CREATE TABLE IF NOT EXISTS filiais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    endereco TEXT NULL,
    empresa_id INT NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE CASCADE,
    INDEX idx_empresa_id (empresa_id),
    INDEX idx_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: usuarios
-- =====================================================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    hierarquia ENUM('visualizador', 'controlador', 'administrador', 'gerente') NOT NULL DEFAULT 'visualizador',
    empresa_id INT NULL,
    filiais_permitidas TEXT NULL, -- JSON com IDs das filiais permitidas
    ativo BOOLEAN DEFAULT TRUE,
    ultimo_login TIMESTAMP NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE SET NULL,
    INDEX idx_email (email),
    INDEX idx_hierarquia (hierarquia),
    INDEX idx_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: treinamentos
-- =====================================================
CREATE TABLE IF NOT EXISTS treinamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    carga_horaria INT NULL,
    validade_meses INT NOT NULL DEFAULT 12, -- Validade em meses
    obrigatorio BOOLEAN DEFAULT TRUE,
    descricao TEXT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ativo (ativo),
    INDEX idx_obrigatorio (obrigatorio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: funcionarios
-- =====================================================
CREATE TABLE IF NOT EXISTS funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    matricula VARCHAR(50) NULL,
    foto VARCHAR(255) NULL,
    empresa_id INT NOT NULL,
    filial_id INT NOT NULL,
    aso_data DATE NULL,
    aso_validade DATE NULL,
    status ENUM('ativo', 'inativo', 'afastado') DEFAULT 'ativo',
    observacoes TEXT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE CASCADE,
    FOREIGN KEY (filial_id) REFERENCES filiais(id) ON DELETE CASCADE,
    INDEX idx_cpf (cpf),
    INDEX idx_matricula (matricula),
    INDEX idx_empresa_id (empresa_id),
    INDEX idx_filial_id (filial_id),
    INDEX idx_status (status),
    INDEX idx_aso_validade (aso_validade)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: funcionario_treinamentos
-- =====================================================
CREATE TABLE IF NOT EXISTS funcionario_treinamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    funcionario_id INT NOT NULL,
    treinamento_id INT NOT NULL,
    data_realizacao DATE NOT NULL,
    data_vencimento DATE NOT NULL,
    certificado_path VARCHAR(255) NULL,
    observacoes TEXT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE CASCADE,
    FOREIGN KEY (treinamento_id) REFERENCES treinamentos(id) ON DELETE CASCADE,
    INDEX idx_funcionario_id (funcionario_id),
    INDEX idx_treinamento_id (treinamento_id),
    INDEX idx_data_vencimento (data_vencimento),
    UNIQUE KEY unique_funcionario_treinamento (funcionario_id, treinamento_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: auditoria
-- =====================================================
CREATE TABLE IF NOT EXISTS auditoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tabela VARCHAR(50) NOT NULL,
    registro_id INT NOT NULL,
    acao ENUM('create', 'update', 'delete') NOT NULL,
    dados_anteriores JSON NULL,
    dados_novos JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_tabela (tabela),
    INDEX idx_registro_id (registro_id),
    INDEX idx_acao (acao),
    INDEX idx_data_hora (data_hora)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: configuracoes
-- =====================================================
CREATE TABLE IF NOT EXISTS configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NULL,
    descricao TEXT NULL,
    tipo ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_chave (chave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABELA: alertas_email
-- =====================================================
CREATE TABLE IF NOT EXISTS alertas_email (
    id INT AUTO_INCREMENT PRIMARY KEY,
    funcionario_id INT NOT NULL,
    tipo ENUM('aso', 'treinamento') NOT NULL,
    referencia_id INT NULL, -- ID do treinamento se tipo = 'treinamento'
    data_vencimento DATE NOT NULL,
    dias_antecedencia INT NOT NULL, -- 30, 15, etc.
    enviado BOOLEAN DEFAULT FALSE,
    data_envio TIMESTAMP NULL,
    email_destinatario VARCHAR(255) NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE CASCADE,
    INDEX idx_funcionario_id (funcionario_id),
    INDEX idx_tipo (tipo),
    INDEX idx_data_vencimento (data_vencimento),
    INDEX idx_enviado (enviado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- VIEWS PARA RELATÓRIOS
-- =====================================================

-- View para funcionários com status de treinamentos
CREATE OR REPLACE VIEW vw_funcionarios_status AS
SELECT 
    f.id,
    f.nome,
    f.cpf,
    f.matricula,
    f.status,
    e.razao_social as empresa,
    fil.nome as filial,
    f.aso_data,
    f.aso_validade,
    CASE 
        WHEN f.aso_validade IS NULL THEN 'sem_aso'
        WHEN f.aso_validade < CURDATE() THEN 'vencido'
        WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 15 DAY) THEN 'vence_15_dias'
        WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'vence_30_dias'
        ELSE 'valido'
    END as status_aso,
    (SELECT COUNT(*) FROM funcionario_treinamentos ft 
     WHERE ft.funcionario_id = f.id AND ft.data_vencimento < CURDATE()) as treinamentos_vencidos,
    (SELECT COUNT(*) FROM funcionario_treinamentos ft 
     WHERE ft.funcionario_id = f.id AND ft.data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) as treinamentos_vencendo,
    f.criado_em,
    f.atualizado_em
FROM funcionarios f
JOIN empresas e ON f.empresa_id = e.id
JOIN filiais fil ON f.filial_id = fil.id
WHERE f.status = 'ativo';

-- View para dashboard
CREATE OR REPLACE VIEW vw_dashboard_stats AS
SELECT 
    (SELECT COUNT(*) FROM funcionarios WHERE status = 'ativo') as total_funcionarios,
    (SELECT COUNT(*) FROM funcionarios WHERE status = 'ativo' AND aso_validade < CURDATE()) as aso_vencidos,
    (SELECT COUNT(*) FROM funcionarios WHERE status = 'ativo' AND aso_validade BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) as aso_vencendo_30_dias,
    (SELECT COUNT(*) FROM funcionario_treinamentos WHERE data_vencimento < CURDATE()) as treinamentos_vencidos,
    (SELECT COUNT(*) FROM funcionario_treinamentos WHERE data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) as treinamentos_vencendo_30_dias,
    (SELECT COUNT(*) FROM empresas WHERE ativo = TRUE) as total_empresas,
    (SELECT COUNT(*) FROM filiais WHERE ativo = TRUE) as total_filiais;

