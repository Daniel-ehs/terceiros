-- =====================================================
-- Sistema de Gestão de Terceiros
-- Script de Dados Iniciais (Seeds)
-- =====================================================

USE gestao_terceiros;

-- =====================================================
-- CONFIGURAÇÕES INICIAIS
-- =====================================================
INSERT INTO configuracoes (chave, valor, descricao, tipo) VALUES
('sistema_nome', 'Sistema de Gestão de Terceiros', 'Nome do sistema', 'string'),
('sistema_versao', '1.0.0', 'Versão do sistema', 'string'),
('empresa_nome', 'Sua Empresa Ltda', 'Nome da empresa proprietária do sistema', 'string'),
('email_smtp_host', 'smtp.gmail.com', 'Servidor SMTP para envio de emails', 'string'),
('email_smtp_port', '587', 'Porta do servidor SMTP', 'number'),
('email_smtp_user', '', 'Usuário do SMTP', 'string'),
('email_smtp_pass', '', 'Senha do SMTP', 'string'),
('email_from_name', 'Sistema de Gestão de Terceiros', 'Nome do remetente dos emails', 'string'),
('email_from_email', 'noreply@suaempresa.com', 'Email do remetente', 'string'),
('alerta_dias_aso', '30,15', 'Dias de antecedência para alertas de ASO', 'string'),
('alerta_dias_treinamento', '30,15', 'Dias de antecedência para alertas de treinamentos', 'string'),
('upload_max_size', '5242880', 'Tamanho máximo de upload em bytes (5MB)', 'number'),
('backup_auto', 'false', 'Backup automático habilitado', 'boolean');

-- =====================================================
-- TREINAMENTOS PADRÃO
-- =====================================================
INSERT INTO treinamentos (nome, carga_horaria, validade_meses, obrigatorio, descricao) VALUES
('ASO - Atestado de Saúde Ocupacional', 0, 12, TRUE, 'Atestado de Saúde Ocupacional obrigatório para todos os funcionários'),
('EPI - Equipamento de Proteção Individual', 4, 12, TRUE, 'Treinamento sobre uso correto de EPIs'),
('NR-10 - Segurança em Instalações e Serviços em Eletricidade', 40, 24, FALSE, 'Treinamento para trabalhos com eletricidade'),
('NR-11 - Transporte, Movimentação, Armazenagem e Manuseio de Materiais', 16, 12, FALSE, 'Treinamento para operação de equipamentos de transporte'),
('NR-12 - Segurança no Trabalho em Máquinas e Equipamentos', 16, 12, FALSE, 'Treinamento para operação segura de máquinas'),
('NR-18 - Condições e Meio Ambiente de Trabalho na Indústria da Construção', 6, 12, FALSE, 'Treinamento para trabalhos na construção civil'),
('NR-20 - Segurança e Saúde no Trabalho com Inflamáveis e Combustíveis', 16, 12, FALSE, 'Treinamento para trabalhos com materiais inflamáveis'),
('NR-33 - Segurança e Saúde nos Trabalhos em Espaços Confinados', 16, 12, FALSE, 'Treinamento para trabalhos em espaços confinados'),
('NR-35 - Trabalho em Altura', 8, 24, FALSE, 'Treinamento para trabalhos em altura'),
('Integração de Segurança', 2, 12, TRUE, 'Treinamento de integração sobre segurança do trabalho'),
('Primeiros Socorros', 8, 24, FALSE, 'Treinamento básico de primeiros socorros'),
('Combate a Incêndio', 4, 12, FALSE, 'Treinamento de prevenção e combate a incêndios');

-- =====================================================
-- EMPRESA E FILIAL EXEMPLO
-- =====================================================
INSERT INTO empresas (razao_social, cnpj, endereco, telefone, email) VALUES
('Empresa Exemplo Ltda', '12.345.678/0001-90', 'Rua das Empresas, 123 - Centro - São Paulo/SP - CEP: 01234-567', '(11) 1234-5678', 'contato@empresaexemplo.com.br');

INSERT INTO filiais (nome, endereco, empresa_id) VALUES
('Filial Principal', 'Rua das Empresas, 123 - Centro - São Paulo/SP', 1),
('Filial Secundária', 'Av. das Indústrias, 456 - Industrial - São Paulo/SP', 1);

-- =====================================================
-- USUÁRIO ADMINISTRADOR PADRÃO
-- =====================================================
-- Senha: admin123 (hash gerado com password_hash em PHP)
INSERT INTO usuarios (nome, email, senha, hierarquia, empresa_id) VALUES
('Administrador do Sistema', 'admin@sistema.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'gerente', 1);

-- =====================================================
-- FUNCIONÁRIOS EXEMPLO
-- =====================================================
INSERT INTO funcionarios (nome, cpf, matricula, empresa_id, filial_id, aso_data, aso_validade, status) VALUES
('João Silva Santos', '123.456.789-01', 'EMP001', 1, 1, '2024-01-15', '2025-01-15', 'ativo'),
('Maria Oliveira Costa', '987.654.321-02', 'EMP002', 1, 1, '2024-02-20', '2025-02-20', 'ativo'),
('Pedro Souza Lima', '456.789.123-03', 'EMP003', 1, 2, '2024-03-10', '2025-03-10', 'ativo'),
('Ana Paula Ferreira', '789.123.456-04', 'EMP004', 1, 2, '2023-12-05', '2024-12-05', 'ativo');

-- =====================================================
-- TREINAMENTOS DOS FUNCIONÁRIOS EXEMPLO
-- =====================================================
-- João Silva Santos
INSERT INTO funcionario_treinamentos (funcionario_id, treinamento_id, data_realizacao, data_vencimento) VALUES
(1, 2, '2024-01-20', '2025-01-20'), -- EPI
(1, 10, '2024-01-22', '2025-01-22'), -- Integração
(1, 5, '2024-02-15', '2025-02-15'); -- NR-12

-- Maria Oliveira Costa
INSERT INTO funcionario_treinamentos (funcionario_id, treinamento_id, data_realizacao, data_vencimento) VALUES
(2, 2, '2024-02-25', '2025-02-25'), -- EPI
(2, 10, '2024-02-25', '2025-02-25'), -- Integração
(2, 9, '2024-03-10', '2026-03-10'); -- NR-35

-- Pedro Souza Lima
INSERT INTO funcionario_treinamentos (funcionario_id, treinamento_id, data_realizacao, data_vencimento) VALUES
(3, 2, '2024-03-15', '2025-03-15'), -- EPI
(3, 10, '2024-03-15', '2025-03-15'), -- Integração
(3, 3, '2024-04-01', '2026-04-01'); -- NR-10

-- Ana Paula Ferreira (alguns treinamentos vencidos para demonstração)
INSERT INTO funcionario_treinamentos (funcionario_id, treinamento_id, data_realizacao, data_vencimento) VALUES
(4, 2, '2023-12-10', '2024-12-10'), -- EPI (vencido)
(4, 10, '2023-12-10', '2024-12-10'), -- Integração (vencido)
(4, 6, '2024-01-15', '2025-01-15'); -- NR-18

-- =====================================================
-- ALERTAS DE EMAIL EXEMPLO
-- =====================================================
INSERT INTO alertas_email (funcionario_id, tipo, data_vencimento, dias_antecedencia, email_destinatario) VALUES
(4, 'aso', '2024-12-05', 30, 'admin@sistema.com'),
(4, 'treinamento', '2024-12-10', 30, 'admin@sistema.com');

-- =====================================================
-- AUDITORIA EXEMPLO
-- =====================================================
INSERT INTO auditoria (usuario_id, tabela, registro_id, acao, dados_novos, ip_address) VALUES
(1, 'funcionarios', 1, 'create', '{"nome": "João Silva Santos", "cpf": "123.456.789-01"}', '127.0.0.1'),
(1, 'funcionarios', 2, 'create', '{"nome": "Maria Oliveira Costa", "cpf": "987.654.321-02"}', '127.0.0.1'),
(1, 'funcionarios', 3, 'create', '{"nome": "Pedro Souza Lima", "cpf": "456.789.123-03"}', '127.0.0.1'),
(1, 'funcionarios', 4, 'create', '{"nome": "Ana Paula Ferreira", "cpf": "789.123.456-04"}', '127.0.0.1');

