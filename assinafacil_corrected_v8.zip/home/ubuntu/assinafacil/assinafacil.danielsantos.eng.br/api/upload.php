<?php
/**
 * API para Upload de Arquivos
 * Sistema de Gestão de Terceiros
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/config.php';

// Verifica autenticação
if (!isValidSession()) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}

try {
    $action = $_POST['action'] ?? 'upload_file';
    
    switch ($action) {
        case 'upload_file':
            // Upload de arquivo único (foto, certificado, etc.)
            if (!isset($_FILES['file'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Nenhum arquivo enviado']);
                exit;
            }
            
            $file = $_FILES['file'];
            $type = $_POST['type'] ?? 'general'; // foto, certificado, documento
            
            // Define tipos permitidos baseado no tipo de upload
            $allowedTypes = UPLOAD_ALLOWED_TYPES;
            if ($type === 'foto') {
                $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            } elseif ($type === 'certificado') {
                $allowedTypes = ['pdf', 'jpg', 'jpeg', 'png'];
            }
            
            $fileName = uploadFile($file, $allowedTypes);
            
            echo json_encode([
                'success' => true,
                'filename' => $fileName,
                'url' => '/gestao_terceiros/assets/img/uploads/' . $fileName,
                'message' => 'Arquivo enviado com sucesso'
            ]);
            break;
            
        case 'import_csv':
            // Importação de planilha CSV
            if (!hasPermission('create')) {
                http_response_code(403);
                echo json_encode(['error' => 'Sem permissão para importar']);
                exit;
            }
            
            if (!isset($_FILES['csv_file'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Nenhum arquivo CSV enviado']);
                exit;
            }
            
            $file = $_FILES['csv_file'];
            $entity = $_POST['entity'] ?? 'funcionarios'; // funcionarios, empresas, etc.
            
            // Verifica se é um arquivo CSV
            $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($fileExtension, ['csv', 'txt'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Arquivo deve ser CSV ou TXT']);
                exit;
            }
            
            // Salva arquivo temporariamente
            $tempPath = sys_get_temp_dir() . '/' . uniqid() . '.csv';
            if (!move_uploaded_file($file['tmp_name'], $tempPath)) {
                http_response_code(500);
                echo json_encode(['error' => 'Erro ao salvar arquivo temporário']);
                exit;
            }
            
            try {
                $db = getDB();
                $db->beginTransaction();
                
                $imported = 0;
                $errors = [];
                
                if ($entity === 'funcionarios') {
                    // Mapeamento de colunas para funcionários
                    $mapping = [
                        'Nome' => 'nome',
                        'CPF' => 'cpf',
                        'Matrícula' => 'matricula',
                        'Empresa' => 'empresa_nome',
                        'Filial' => 'filial_nome',
                        'Data ASO' => 'aso_data',
                        'Status' => 'status',
                        'Observações' => 'observacoes'
                    ];
                    
                    $data = processCSVImport($tempPath, $mapping);
                    
                    foreach ($data as $index => $row) {
                        $rowNumber = $index + 2; // +2 porque começa na linha 2 (após cabeçalho)
                        
                        try {
                            // Validações
                            if (empty($row['nome'])) {
                                $errors[] = "Linha {$rowNumber}: Nome é obrigatório";
                                continue;
                            }
                            
                            if (empty($row['cpf']) || !validateCPF($row['cpf'])) {
                                $errors[] = "Linha {$rowNumber}: CPF inválido";
                                continue;
                            }
                            
                            // Busca empresa
                            $empresa = null;
                            if (!empty($row['empresa_nome'])) {
                                $empresa = $db->fetch("SELECT id FROM empresas WHERE razao_social LIKE ?", ['%' . $row['empresa_nome'] . '%']);
                            }
                            
                            if (!$empresa) {
                                $errors[] = "Linha {$rowNumber}: Empresa não encontrada";
                                continue;
                            }
                            
                            // Busca filial
                            $filial = null;
                            if (!empty($row['filial_nome'])) {
                                $filial = $db->fetch("SELECT id FROM filiais WHERE nome LIKE ? AND empresa_id = ?", ['%' . $row['filial_nome'] . '%', $empresa['id']]);
                            }
                            
                            if (!$filial) {
                                $errors[] = "Linha {$rowNumber}: Filial não encontrada";
                                continue;
                            }
                            
                            // Verifica se CPF já existe
                            $cpf = preg_replace('/[^0-9]/', '', $row['cpf']);
                            $cpfExists = $db->fetch("SELECT id FROM funcionarios WHERE cpf = ?", [$cpf]);
                            
                            if ($cpfExists) {
                                $errors[] = "Linha {$rowNumber}: CPF já cadastrado";
                                continue;
                            }
                            
                            // Insere funcionário
                            $asoData = !empty($row['aso_data']) ? date('Y-m-d', strtotime($row['aso_data'])) : null;
                            $asoValidade = $asoData ? calculateExpirationDate($asoData, 12) : null;
                            $status = !empty($row['status']) ? $row['status'] : 'ativo';
                            
                            $sql = "INSERT INTO funcionarios (nome, cpf, matricula, empresa_id, filial_id, aso_data, aso_validade, status, observacoes) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                            
                            $params = [
                                $row['nome'],
                                $cpf,
                                $row['matricula'] ?? null,
                                $empresa['id'],
                                $filial['id'],
                                $asoData,
                                $asoValidade,
                                $status,
                                $row['observacoes'] ?? null
                            ];
                            
                            $db->execute($sql, $params);
                            $funcionarioId = $db->lastInsertId();
                            
                            // Log auditoria
                            logAuditoria('funcionarios', $funcionarioId, 'create', null, $row);
                            
                            $imported++;
                            
                        } catch (Exception $e) {
                            $errors[] = "Linha {$rowNumber}: " . $e->getMessage();
                        }
                    }
                }
                
                $db->commit();
                
                // Remove arquivo temporário
                unlink($tempPath);
                
                echo json_encode([
                    'success' => true,
                    'imported' => $imported,
                    'errors' => $errors,
                    'message' => "Importação concluída. {$imported} registros importados."
                ]);
                
            } catch (Exception $e) {
                $db->rollback();
                unlink($tempPath);
                throw $e;
            }
            break;
            
        case 'upload_multiple':
            // Upload múltiplo de arquivos
            if (!isset($_FILES['files'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Nenhum arquivo enviado']);
                exit;
            }
            
            $files = $_FILES['files'];
            $uploaded = [];
            $errors = [];
            
            // Normaliza array de arquivos múltiplos
            if (!is_array($files['name'])) {
                $files = [
                    'name' => [$files['name']],
                    'type' => [$files['type']],
                    'tmp_name' => [$files['tmp_name']],
                    'error' => [$files['error']],
                    'size' => [$files['size']]
                ];
            }
            
            for ($i = 0; $i < count($files['name']); $i++) {
                try {
                    $file = [
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    
                    $fileName = uploadFile($file);
                    $uploaded[] = [
                        'original_name' => $file['name'],
                        'filename' => $fileName,
                        'url' => '/gestao_terceiros/assets/img/uploads/' . $fileName
                    ];
                    
                } catch (Exception $e) {
                    $errors[] = $files['name'][$i] . ': ' . $e->getMessage();
                }
            }
            
            echo json_encode([
                'success' => count($uploaded) > 0,
                'uploaded' => $uploaded,
                'errors' => $errors,
                'message' => count($uploaded) . ' arquivo(s) enviado(s) com sucesso'
            ]);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Ação não reconhecida']);
            break;
    }
    
} catch (Exception $e) {
    error_log("Erro na API de upload: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Erro interno do servidor: ' . $e->getMessage()]);
}
?>

