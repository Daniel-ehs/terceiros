<?php
/**
 * API para Dashboard
 * Sistema de Gestão de Terceiros
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// Verifica autenticação
if (!isValidSession()) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

try {
    $db = getDB();
    $action = $_GET['action'] ?? 'stats';
    
    switch ($action) {
        case 'stats':
            // Estatísticas gerais
            $stats = getDashboardStats();
            echo json_encode($stats);
            break;
            
        case 'funcionarios_status':
            // Lista de funcionários com status visual (farol)
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
            
            $sql = "SELECT f.id, f.nome, f.cpf, f.matricula, f.status,
                           e.razao_social as empresa, fil.nome as filial,
                           f.aso_data, f.aso_validade,
                           CASE 
                               WHEN f.aso_validade IS NULL THEN 'sem_aso'
                               WHEN f.aso_validade < CURDATE() THEN 'vencido'
                               WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 15 DAY) THEN 'vence_15_dias'
                               WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'vence_30_dias'
                               ELSE 'valido'
                           END as status_aso,
                           (SELECT COUNT(*) FROM funcionario_treinamentos ft 
                            WHERE ft.funcionario_id = f.id AND ft.data_vencimento < CURDATE()) as treinamentos_vencidos,
                           (SELECT COUNT(*) FROM funcionario_treinamentos ft 
                            WHERE ft.funcionario_id = f.id AND ft.data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) as treinamentos_vencendo
                    FROM funcionarios f
                    JOIN empresas e ON f.empresa_id = e.id
                    JOIN filiais fil ON f.filial_id = fil.id
                    WHERE f.status = 'ativo'
                    ORDER BY 
                        CASE 
                            WHEN f.aso_validade < CURDATE() THEN 1
                            WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 15 DAY) THEN 2
                            WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 3
                            ELSE 4
                        END,
                        f.nome
                    LIMIT ?";
            
            $funcionarios = $db->fetchAll($sql, [$limit]);
            
            // Adiciona status geral (farol)
            foreach ($funcionarios as &$funcionario) {
                $statusGeral = 'valido'; // Verde
                
                // Verifica ASO
                if ($funcionario['status_aso'] === 'vencido') {
                    $statusGeral = 'vencido'; // Vermelho
                } elseif ($funcionario['status_aso'] === 'vence_15_dias') {
                    $statusGeral = 'vence_15_dias'; // Laranja
                } elseif ($funcionario['status_aso'] === 'vence_30_dias' && $statusGeral === 'valido') {
                    $statusGeral = 'vence_30_dias'; // Amarelo
                }
                
                // Verifica treinamentos
                if ($funcionario['treinamentos_vencidos'] > 0) {
                    $statusGeral = 'vencido'; // Vermelho
                } elseif ($funcionario['treinamentos_vencendo'] > 0 && !in_array($statusGeral, ['vencido', 'vence_15_dias'])) {
                    $statusGeral = $statusGeral === 'valido' ? 'vence_30_dias' : $statusGeral; // Amarelo
                }
                
                $funcionario['status_geral'] = $statusGeral;
                $funcionario['cpf_formatado'] = formatCPF($funcionario['cpf']);
                $funcionario['aso_data_formatada'] = formatDate($funcionario['aso_data']);
                $funcionario['aso_validade_formatada'] = formatDate($funcionario['aso_validade']);
            }
            
            echo json_encode($funcionarios);
            break;
            
        case 'alertas':
            // Alertas de vencimento
            $sql = "SELECT 'aso' as tipo, f.id as funcionario_id, f.nome, f.aso_validade as data_vencimento,
                           e.razao_social as empresa, fil.nome as filial,
                           DATEDIFF(f.aso_validade, CURDATE()) as dias_restantes
                    FROM funcionarios f
                    JOIN empresas e ON f.empresa_id = e.id
                    JOIN filiais fil ON f.filial_id = fil.id
                    WHERE f.status = 'ativo' 
                    AND f.aso_validade IS NOT NULL
                    AND f.aso_validade BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                    
                    UNION ALL
                    
                    SELECT 'treinamento' as tipo, f.id as funcionario_id, f.nome, ft.data_vencimento,
                           e.razao_social as empresa, fil.nome as filial,
                           DATEDIFF(ft.data_vencimento, CURDATE()) as dias_restantes
                    FROM funcionarios f
                    JOIN funcionario_treinamentos ft ON f.id = ft.funcionario_id
                    JOIN treinamentos t ON ft.treinamento_id = t.id
                    JOIN empresas e ON f.empresa_id = e.id
                    JOIN filiais fil ON f.filial_id = fil.id
                    WHERE f.status = 'ativo' 
                    AND ft.data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                    
                    ORDER BY dias_restantes, nome";
            
            $alertas = $db->fetchAll($sql);
            
            foreach ($alertas as &$alerta) {
                $alerta['data_vencimento_formatada'] = formatDate($alerta['data_vencimento']);
                
                if ($alerta['dias_restantes'] < 0) {
                    $alerta['status'] = 'vencido';
                    $alerta['urgencia'] = 'alta';
                } elseif ($alerta['dias_restantes'] <= 15) {
                    $alerta['status'] = 'vence_15_dias';
                    $alerta['urgencia'] = 'media';
                } else {
                    $alerta['status'] = 'vence_30_dias';
                    $alerta['urgencia'] = 'baixa';
                }
            }
            
            echo json_encode($alertas);
            break;
            
        case 'graficos':
            // Dados para gráficos
            $graficos = [];
            
            // Gráfico de funcionários por empresa
            $sql = "SELECT e.razao_social as empresa, COUNT(f.id) as total
                    FROM empresas e
                    LEFT JOIN funcionarios f ON e.id = f.empresa_id AND f.status = 'ativo'
                    WHERE e.ativo = TRUE
                    GROUP BY e.id, e.razao_social
                    ORDER BY total DESC";
            
            $graficos['funcionarios_por_empresa'] = $db->fetchAll($sql);
            
            // Gráfico de status de ASO
            $sql = "SELECT 
                        SUM(CASE WHEN f.aso_validade IS NULL THEN 1 ELSE 0 END) as sem_aso,
                        SUM(CASE WHEN f.aso_validade < CURDATE() THEN 1 ELSE 0 END) as vencidos,
                        SUM(CASE WHEN f.aso_validade BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as vencendo,
                        SUM(CASE WHEN f.aso_validade > DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as validos
                    FROM funcionarios f
                    WHERE f.status = 'ativo'";
            
            $statusAso = $db->fetch($sql);
            $graficos['status_aso'] = [
                ['status' => 'Válidos', 'quantidade' => (int)$statusAso['validos']],
                ['status' => 'Vencendo (30 dias)', 'quantidade' => (int)$statusAso['vencendo']],
                ['status' => 'Vencidos', 'quantidade' => (int)$statusAso['vencidos']],
                ['status' => 'Sem ASO', 'quantidade' => (int)$statusAso['sem_aso']]
            ];
            
            // Gráfico de treinamentos mais vencidos
            $sql = "SELECT t.nome as treinamento, COUNT(ft.id) as vencidos
                    FROM funcionario_treinamentos ft
                    JOIN treinamentos t ON ft.treinamento_id = t.id
                    JOIN funcionarios f ON ft.funcionario_id = f.id
                    WHERE f.status = 'ativo' AND ft.data_vencimento < CURDATE()
                    GROUP BY t.id, t.nome
                    ORDER BY vencidos DESC
                    LIMIT 10";
            
            $graficos['treinamentos_vencidos'] = $db->fetchAll($sql);
            
            echo json_encode($graficos);
            break;
            
        case 'resumo_mensal':
            // Resumo mensal para relatórios
            $ano = isset($_GET['ano']) ? (int)$_GET['ano'] : date('Y');
            
            $resumo = [];
            
            for ($mes = 1; $mes <= 12; $mes++) {
                $dataInicio = "{$ano}-{$mes}-01";
                $dataFim = date('Y-m-t', strtotime($dataInicio));
                
                // Funcionários cadastrados no mês
                $funcionariosCadastrados = $db->fetch(
                    "SELECT COUNT(*) as total FROM funcionarios WHERE DATE(criado_em) BETWEEN ? AND ?",
                    [$dataInicio, $dataFim]
                )['total'];
                
                // ASOs que venceram no mês
                $asosVencidos = $db->fetch(
                    "SELECT COUNT(*) as total FROM funcionarios WHERE aso_validade BETWEEN ? AND ? AND status = 'ativo'",
                    [$dataInicio, $dataFim]
                )['total'];
                
                // Treinamentos que venceram no mês
                $treinamentosVencidos = $db->fetch(
                    "SELECT COUNT(*) as total FROM funcionario_treinamentos ft
                     JOIN funcionarios f ON ft.funcionario_id = f.id
                     WHERE ft.data_vencimento BETWEEN ? AND ? AND f.status = 'ativo'",
                    [$dataInicio, $dataFim]
                )['total'];
                
                $resumo[] = [
                    'mes' => $mes,
                    'mes_nome' => date('F', mktime(0, 0, 0, $mes, 1)),
                    'funcionarios_cadastrados' => (int)$funcionariosCadastrados,
                    'asos_vencidos' => (int)$asosVencidos,
                    'treinamentos_vencidos' => (int)$treinamentosVencidos
                ];
            }
            
            echo json_encode($resumo);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Ação não reconhecida']);
            break;
    }
    
} catch (Exception $e) {
    error_log("Erro na API do dashboard: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Erro interno do servidor']);
}
?>
