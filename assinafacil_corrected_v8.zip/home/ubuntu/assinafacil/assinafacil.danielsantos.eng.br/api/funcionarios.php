<?php
/**
 * API REST para Funcionários
 * Sistema de Gestão de Terceiros
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/config.php';

// Verifica autenticação
if (!isValidSession()) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    $db = getDB();
    
    switch ($method) {
        case 'GET':
            if ($id) {
                // Buscar funcionário específico
                $sql = "SELECT f.*, e.razao_social as empresa_nome, fil.nome as filial_nome,
                               CASE 
                                   WHEN f.aso_validade IS NULL THEN 'sem_aso'
                                   WHEN f.aso_validade < CURDATE() THEN 'vencido'
                                   WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 15 DAY) THEN 'vence_15_dias'
                                   WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'vence_30_dias'
                                   ELSE 'valido'
                               END as status_aso
                        FROM funcionarios f
                        JOIN empresas e ON f.empresa_id = e.id
                        JOIN filiais fil ON f.filial_id = fil.id
                        WHERE f.id = ?";
                
                $funcionario = $db->fetch($sql, [$id]);
                
                if (!$funcionario) {
                    http_response_code(404);
                    echo json_encode(['error' => 'Funcionário não encontrado']);
                    exit;
                }
                
                // Buscar treinamentos do funcionário
                $sql = "SELECT ft.*, t.nome as treinamento_nome, t.validade_meses,
                               CASE 
                                   WHEN ft.data_vencimento < CURDATE() THEN 'vencido'
                                   WHEN ft.data_vencimento <= DATE_ADD(CURDATE(), INTERVAL 15 DAY) THEN 'vence_15_dias'
                                   WHEN ft.data_vencimento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'vence_30_dias'
                                   ELSE 'valido'
                               END as status_treinamento
                        FROM funcionario_treinamentos ft
                        JOIN treinamentos t ON ft.treinamento_id = t.id
                        WHERE ft.funcionario_id = ?
                        ORDER BY ft.data_vencimento";
                
                $treinamentos = $db->fetchAll($sql, [$id]);
                $funcionario['treinamentos'] = $treinamentos;
                
                echo json_encode($funcionario);
                
            } else {
                // Listar funcionários com filtros
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : ITEMS_PER_PAGE;
                $offset = ($page - 1) * $limit;
                
                $where = ['f.id > 0'];
                $params = [];
                
                // Filtros
                if (isset($_GET['empresa_id']) && $_GET['empresa_id']) {
                    $where[] = 'f.empresa_id = ?';
                    $params[] = $_GET['empresa_id'];
                }
                
                if (isset($_GET['filial_id']) && $_GET['filial_id']) {
                    $where[] = 'f.filial_id = ?';
                    $params[] = $_GET['filial_id'];
                }
                
                if (isset($_GET['status']) && $_GET['status']) {
                    $where[] = 'f.status = ?';
                    $params[] = $_GET['status'];
                }
                
                if (isset($_GET['search']) && $_GET['search']) {
                    $search = '%' . $_GET['search'] . '%';
                    $where[] = '(f.nome LIKE ? OR f.cpf LIKE ? OR f.matricula LIKE ?)';
                    $params[] = $search;
                    $params[] = $search;
                    $params[] = $search;
                }
                
                $whereClause = implode(' AND ', $where);
                
                // Contar total
                $countSql = "SELECT COUNT(*) as total FROM funcionarios f WHERE {$whereClause}";
                $total = $db->fetch($countSql, $params)['total'];
                
                // Buscar dados
                $sql = "SELECT f.*, e.razao_social as empresa_nome, fil.nome as filial_nome,
                               CASE 
                                   WHEN f.aso_validade IS NULL THEN 'sem_aso'
                                   WHEN f.aso_validade < CURDATE() THEN 'vencido'
                                   WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 15 DAY) THEN 'vence_15_dias'
                                   WHEN f.aso_validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'vence_30_dias'
                                   ELSE 'valido'
                               END as status_aso,
                               (SELECT COUNT(*) FROM funcionario_treinamentos ft 
                                WHERE ft.funcionario_id = f.id AND ft.data_vencimento < CURDATE()) as treinamentos_vencidos
                        FROM funcionarios f
                        JOIN empresas e ON f.empresa_id = e.id
                        JOIN filiais fil ON f.filial_id = fil.id
                        WHERE {$whereClause}
                        ORDER BY f.nome
                        LIMIT {$limit} OFFSET {$offset}";
                
                $funcionarios = $db->fetchAll($sql, $params);
                
                echo json_encode([
                    'data' => $funcionarios,
                    'total' => $total,
                    'page' => $page,
                    'limit' => $limit,
                    'pages' => ceil($total / $limit)
                ]);
            }
            break;
            
        case 'POST':
            // Criar funcionário
            if (!hasPermission('create')) {
                http_response_code(403);
                echo json_encode(['error' => 'Sem permissão para criar']);
                exit;
            }
            
            // Validações
            $errors = [];
            
            if (empty($input['nome'])) {
                $errors[] = 'Nome é obrigatório';
            }
            
            if (empty($input['cpf'])) {
                $errors[] = 'CPF é obrigatório';
            } elseif (!validateCPF($input['cpf'])) {
                $errors[] = 'CPF inválido';
            }
            
            if (empty($input['empresa_id'])) {
                $errors[] = 'Empresa é obrigatória';
            }
            
            if (empty($input['filial_id'])) {
                $errors[] = 'Filial é obrigatória';
            }
            
            // Verifica se CPF já existe
            if (!empty($input['cpf'])) {
                $cpfExists = $db->fetch("SELECT id FROM funcionarios WHERE cpf = ?", [preg_replace('/[^0-9]/', '', $input['cpf'])]);
                if ($cpfExists) {
                    $errors[] = 'CPF já cadastrado';
                }
            }
            
            if (!empty($errors)) {
                http_response_code(400);
                echo json_encode(['errors' => $errors]);
                exit;
            }
            
            // Inserir funcionário
            $sql = "INSERT INTO funcionarios (nome, cpf, matricula, empresa_id, filial_id, aso_data, aso_validade, status, observacoes) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $cpf = preg_replace('/[^0-9]/', '', $input['cpf']);
            $asoData = !empty($input['aso_data']) ? $input['aso_data'] : null;
            $asoValidade = null;
            
            if ($asoData) {
                $asoValidade = calculateExpirationDate($asoData, 12); // ASO válido por 12 meses
            }
            
            $params = [
                $input['nome'],
                $cpf,
                $input['matricula'] ?? null,
                $input['empresa_id'],
                $input['filial_id'],
                $asoData,
                $asoValidade,
                $input['status'] ?? 'ativo',
                $input['observacoes'] ?? null
            ];
            
            $db->execute($sql, $params);
            $funcionarioId = $db->lastInsertId();
            
            // Log auditoria
            logAuditoria('funcionarios', $funcionarioId, 'create', null, $input);
            
            echo json_encode(['id' => $funcionarioId, 'message' => 'Funcionário criado com sucesso']);
            break;
            
        case 'PUT':
            // Atualizar funcionário
            if (!$id) {
                http_response_code(400);
                echo json_encode(['error' => 'ID é obrigatório']);
                exit;
            }
            
            if (!hasPermission('update')) {
                http_response_code(403);
                echo json_encode(['error' => 'Sem permissão para atualizar']);
                exit;
            }
            
            // Buscar dados anteriores
            $dadosAnteriores = $db->fetch("SELECT * FROM funcionarios WHERE id = ?", [$id]);
            
            if (!$dadosAnteriores) {
                http_response_code(404);
                echo json_encode(['error' => 'Funcionário não encontrado']);
                exit;
            }
            
            // Validações
            $errors = [];
            
            if (empty($input['nome'])) {
                $errors[] = 'Nome é obrigatório';
            }
            
            if (empty($input['cpf'])) {
                $errors[] = 'CPF é obrigatório';
            } elseif (!validateCPF($input['cpf'])) {
                $errors[] = 'CPF inválido';
            }
            
            // Verifica se CPF já existe (exceto o próprio registro)
            if (!empty($input['cpf'])) {
                $cpfExists = $db->fetch("SELECT id FROM funcionarios WHERE cpf = ? AND id != ?", [preg_replace('/[^0-9]/', '', $input['cpf']), $id]);
                if ($cpfExists) {
                    $errors[] = 'CPF já cadastrado';
                }
            }
            
            if (!empty($errors)) {
                http_response_code(400);
                echo json_encode(['errors' => $errors]);
                exit;
            }
            
            // Atualizar funcionário
            $sql = "UPDATE funcionarios SET nome = ?, cpf = ?, matricula = ?, empresa_id = ?, filial_id = ?, 
                           aso_data = ?, aso_validade = ?, status = ?, observacoes = ?, atualizado_em = NOW() 
                    WHERE id = ?";
            
            $cpf = preg_replace('/[^0-9]/', '', $input['cpf']);
            $asoData = !empty($input['aso_data']) ? $input['aso_data'] : null;
            $asoValidade = null;
            
            if ($asoData) {
                $asoValidade = calculateExpirationDate($asoData, 12);
            }
            
            $params = [
                $input['nome'],
                $cpf,
                $input['matricula'] ?? null,
                $input['empresa_id'],
                $input['filial_id'],
                $asoData,
                $asoValidade,
                $input['status'] ?? 'ativo',
                $input['observacoes'] ?? null,
                $id
            ];
            
            $db->execute($sql, $params);
            
            // Log auditoria
            logAuditoria('funcionarios', $id, 'update', $dadosAnteriores, $input);
            
            echo json_encode(['message' => 'Funcionário atualizado com sucesso']);
            break;
            
        case 'DELETE':
            // Excluir funcionário
            if (!$id) {
                http_response_code(400);
                echo json_encode(['error' => 'ID é obrigatório']);
                exit;
            }
            
            if (!hasPermission('delete')) {
                http_response_code(403);
                echo json_encode(['error' => 'Sem permissão para excluir']);
                exit;
            }
            
            // Buscar dados anteriores
            $dadosAnteriores = $db->fetch("SELECT * FROM funcionarios WHERE id = ?", [$id]);
            
            if (!$dadosAnteriores) {
                http_response_code(404);
                echo json_encode(['error' => 'Funcionário não encontrado']);
                exit;
            }
            
            // Excluir funcionário
            $db->execute("DELETE FROM funcionarios WHERE id = ?", [$id]);
            
            // Log auditoria
            logAuditoria('funcionarios', $id, 'delete', $dadosAnteriores, null);
            
            echo json_encode(['message' => 'Funcionário excluído com sucesso']);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Método não permitido']);
            break;
    }
    
} catch (Exception $e) {
    error_log("Erro na API de funcionários: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Erro interno do servidor']);
}
?>

