<?php
/**
 * Dashboard Principal
 * Sistema de Gestão de Terceiros
 */

require_once 'config/config.php';
require_once 'includes/functions.php';

$pageTitle = 'Dashboard';
$breadcrumb = [];

// Buscar estatísticas
try {
    $stats = getDashboardStats();
} catch (Exception $e) {
    $stats = [
        'total_funcionarios' => 0,
        'aso_vencidos' => 0,
        'aso_vencendo_30_dias' => 0,
        'treinamentos_vencidos' => 0,
        'treinamentos_vencendo_30_dias' => 0,
        'total_empresas' => 0,
        'total_filiais' => 0
    ];
}

$additionalJS = [
    'https://cdn.jsdelivr.net/npm/chart.js'
];

$inlineJS = '
// Carregar dados do dashboard
document.addEventListener("DOMContentLoaded", function() {
    loadDashboardData();
});

async function loadDashboardData() {
    try {
        // Carregar funcionários com status
        const funcionarios = await API.dashboard.getFuncionariosStatus(20);
        renderFuncionariosTable(funcionarios);
        
        // Carregar alertas
        const alertas = await API.dashboard.getAlertas();
        renderAlertas(alertas);
        
        // Carregar gráficos
        const graficos = await API.dashboard.getGraficos();
        renderGraficos(graficos);
        
    } catch (error) {
        console.error("Erro ao carregar dados do dashboard:", error);
        Utils.showToast("Erro ao carregar dados do dashboard", "danger");
    }
}

function renderFuncionariosTable(funcionarios) {
    const tbody = document.getElementById("funcionarios-tbody");
    if (!tbody) return;
    
    tbody.innerHTML = funcionarios.map(func => `
        <tr>
            <td>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div class="status-indicator status-${func.status_geral}"></div>
                    <div>
                        <strong>${func.nome}</strong><br>
                        <small style="color: var(--gray);">${func.cpf_formatado}</small>
                    </div>
                </div>
            </td>
            <td>${func.empresa}</td>
            <td>${func.filial}</td>
            <td>
                <span class="status-badge status-${func.status_aso}">
                    ${func.aso_validade_formatada || "Sem ASO"}
                </span>
            </td>
            <td>
                ${func.treinamentos_vencidos > 0 ? 
                    `<span class="status-badge status-vencido">${func.treinamentos_vencidos} vencido(s)</span>` :
                    func.treinamentos_vencendo > 0 ?
                    `<span class="status-badge status-vence-30-dias">${func.treinamentos_vencendo} vencendo</span>` :
                    `<span class="status-badge status-valido">Em dia</span>`
                }
            </td>
            <td>
                <a href="/gestao_terceiros/modules/funcionarios/visualizar.php?id=${func.id}" class="btn btn-sm btn-outline">
                    <i class="fas fa-eye"></i>
                </a>
            </td>
        </tr>
    `).join("");
}

function renderAlertas(alertas) {
    const container = document.getElementById("alertas-container");
    if (!container) return;
    
    if (alertas.length === 0) {
        container.innerHTML = `
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                Nenhum alerta no momento. Todos os documentos estão em dia!
            </div>
        `;
        return;
    }
    
    const alertasHTML = alertas.slice(0, 10).map(alerta => `
        <div class="alert alert-${alerta.urgencia === "alta" ? "danger" : alerta.urgencia === "media" ? "warning" : "info"}">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <strong>${alerta.nome}</strong> - ${alerta.tipo === "aso" ? "ASO" : "Treinamento"}
                    <br>
                    <small>${alerta.empresa} - ${alerta.filial}</small>
                </div>
                <div style="text-align: right;">
                    <strong>${alerta.data_vencimento_formatada}</strong>
                    <br>
                    <small>${alerta.dias_restantes} dia(s)</small>
                </div>
            </div>
        </div>
    `).join("");
    
    container.innerHTML = alertasHTML;
}

function renderGraficos(graficos) {
    // Gráfico de status ASO
    const asoCtx = document.getElementById("grafico-aso");
    if (asoCtx && graficos.status_aso) {
        new Chart(asoCtx, {
            type: "doughnut",
            data: {
                labels: graficos.status_aso.map(item => item.status),
                datasets: [{
                    data: graficos.status_aso.map(item => item.quantidade),
                    backgroundColor: [
                        "var(--success)",
                        "var(--warning)", 
                        "var(--danger)",
                        "var(--gray)"
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: "bottom"
                    }
                }
            }
        });
    }
    
    // Gráfico de funcionários por empresa
    const empresaCtx = document.getElementById("grafico-empresas");
    if (empresaCtx && graficos.funcionarios_por_empresa) {
        new Chart(empresaCtx, {
            type: "bar",
            data: {
                labels: graficos.funcionarios_por_empresa.map(item => item.empresa),
                datasets: [{
                    label: "Funcionários",
                    data: graficos.funcionarios_por_empresa.map(item => item.total),
                    backgroundColor: "var(--primary-green)",
                    borderColor: "var(--primary-green-dark)",
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}
';

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </h2>
        <div class="card-actions">
            <button onclick="loadDashboardData()" class="btn btn-outline btn-sm">
                <i class="fas fa-sync-alt"></i>
                Atualizar
            </button>
        </div>
    </div>
</div>

<!-- Estatísticas -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">Total de Funcionários</span>
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
        </div>
        <div class="stat-value"><?php echo number_format($stats['total_funcionarios']); ?></div>
        <div class="stat-change positive">
            <i class="fas fa-arrow-up"></i>
            Ativos no sistema
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">ASOs Vencidos</span>
            <div class="stat-icon" style="background: linear-gradient(135deg, var(--danger) 0%, #c62828 100%);">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
        </div>
        <div class="stat-value" style="color: var(--danger);"><?php echo number_format($stats['aso_vencidos']); ?></div>
        <div class="stat-change negative">
            <i class="fas fa-arrow-down"></i>
            Requer atenção imediata
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">ASOs Vencendo (30 dias)</span>
            <div class="stat-icon" style="background: linear-gradient(135deg, var(--warning) 0%, #f57c00 100%);">
                <i class="fas fa-clock"></i>
            </div>
        </div>
        <div class="stat-value" style="color: var(--warning);"><?php echo number_format($stats['aso_vencendo_30_dias']); ?></div>
        <div class="stat-change">
            <i class="fas fa-calendar-alt"></i>
            Próximos vencimentos
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">Treinamentos Vencidos</span>
            <div class="stat-icon" style="background: linear-gradient(135deg, var(--danger) 0%, #c62828 100%);">
                <i class="fas fa-graduation-cap"></i>
            </div>
        </div>
        <div class="stat-value" style="color: var(--danger);"><?php echo number_format($stats['treinamentos_vencidos']); ?></div>
        <div class="stat-change negative">
            <i class="fas fa-arrow-down"></i>
            Necessário renovação
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">Treinamentos Vencendo</span>
            <div class="stat-icon" style="background: linear-gradient(135deg, var(--warning) 0%, #f57c00 100%);">
                <i class="fas fa-hourglass-half"></i>
            </div>
        </div>
        <div class="stat-value" style="color: var(--warning);"><?php echo number_format($stats['treinamentos_vencendo_30_dias']); ?></div>
        <div class="stat-change">
            <i class="fas fa-calendar-check"></i>
            Próximos 30 dias
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">Empresas Cadastradas</span>
            <div class="stat-icon" style="background: linear-gradient(135deg, var(--info) 0%, #1976d2 100%);">
                <i class="fas fa-building"></i>
            </div>
        </div>
        <div class="stat-value" style="color: var(--info);"><?php echo number_format($stats['total_empresas']); ?></div>
        <div class="stat-change positive">
            <i class="fas fa-arrow-up"></i>
            Parceiros ativos
        </div>
    </div>
</div>

<!-- Conteúdo Principal -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px; margin-top: 20px;">
    <!-- Funcionários com Status Visual -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-traffic-light"></i>
                Status dos Funcionários (Farol)
            </h3>
            <div class="card-actions">
                <a href="modules/funcionarios/" class="btn btn-outline btn-sm">
                    <i class="fas fa-list"></i>
                    Ver Todos
                </a>
            </div>
        </div>
        
        <div style="margin-bottom: 20px;">
            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 5px;">
                    <div class="status-indicator status-valido"></div>
                    <small>Válido</small>
                </div>
                <div style="display: flex; align-items: center; gap: 5px;">
                    <div class="status-indicator status-vence-30-dias"></div>
                    <small>Vence em 30 dias</small>
                </div>
                <div style="display: flex; align-items: center; gap: 5px;">
                    <div class="status-indicator status-vence-15-dias"></div>
                    <small>Vence em 15 dias</small>
                </div>
                <div style="display: flex; align-items: center; gap: 5px;">
                    <div class="status-indicator status-vencido"></div>
                    <small>Vencido</small>
                </div>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Funcionário</th>
                        <th>Empresa</th>
                        <th>Filial</th>
                        <th>ASO</th>
                        <th>Treinamentos</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="funcionarios-tbody">
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px;">
                            <i class="loading"></i> Carregando dados...
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Alertas -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-bell"></i>
                Alertas de Vencimento
            </h3>
        </div>
        
        <div id="alertas-container">
            <div style="text-align: center; padding: 40px;">
                <i class="loading"></i> Carregando alertas...
            </div>
        </div>
    </div>
</div>

<!-- Gráficos -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 30px;">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-chart-pie"></i>
                Status dos ASOs
            </h3>
        </div>
        <div style="height: 300px; display: flex; align-items: center; justify-content: center;">
            <canvas id="grafico-aso"></canvas>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-chart-bar"></i>
                Funcionários por Empresa
            </h3>
        </div>
        <div style="height: 300px; display: flex; align-items: center; justify-content: center;">
            <canvas id="grafico-empresas"></canvas>
        </div>
    </div>
</div>

<style>
.status-indicator {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    display: inline-block;
}

.status-indicator.status-valido {
    background: var(--success);
    box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3);
}

.status-indicator.status-vence-30-dias {
    background: var(--warning);
    box-shadow: 0 0 0 2px rgba(255, 152, 0, 0.3);
}

.status-indicator.status-vence-15-dias {
    background: #e65100;
    box-shadow: 0 0 0 2px rgba(230, 81, 0, 0.3);
}

.status-indicator.status-vencido {
    background: var(--danger);
    box-shadow: 0 0 0 2px rgba(244, 67, 54, 0.3);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { box-shadow: 0 0 0 2px rgba(244, 67, 54, 0.3); }
    50% { box-shadow: 0 0 0 6px rgba(244, 67, 54, 0.1); }
    100% { box-shadow: 0 0 0 2px rgba(244, 67, 54, 0.3); }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    div[style*="grid-template-columns: 2fr 1fr"] {
        grid-template-columns: 1fr !important;
    }
    
    div[style*="grid-template-columns: 1fr 1fr"] {
        grid-template-columns: 1fr !important;
    }
}
</style>

<?php include 'includes/footer.php'; ?>

