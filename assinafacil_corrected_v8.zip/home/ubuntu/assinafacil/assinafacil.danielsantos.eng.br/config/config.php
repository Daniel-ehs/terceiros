<?php
/**
 * Configurações Gerais do Sistema
 * Sistema de Gestão de Terceiros
 */

// Configurações de sessão
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Mude para 1 se usar HTTPS
session_start();

// Configurações de erro
error_reporting(E_ALL);
ini_set('display_errors', 0); // Mude para 1 em desenvolvimento
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// Configurações de timezone
date_default_timezone_set('America/Sao_Paulo');

// Configurações do sistema
define('SYSTEM_NAME', 'Sistema de Gestão de Terceiros');
define('SYSTEM_VERSION', '1.0.0');
define('SYSTEM_URL', 'https://assinafacil.danielsantos.eng.br');

// Configurações de upload
define('UPLOAD_PATH', __DIR__ . '/../assets/img/uploads/');
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('UPLOAD_ALLOWED_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);

// Configurações de paginação
define('ITEMS_PER_PAGE', 20);

// Configurações de segurança
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SESSION_TIMEOUT', 3600); // 1 hora

// Configurações de email
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', '');
define('MAIL_PASSWORD', '');
define('MAIL_FROM_EMAIL', 'noreply@sistema.com');
define('MAIL_FROM_NAME', 'Sistema de Gestão de Terceiros');

// Hierarquias de usuário
define('USER_HIERARCHIES', [
    'visualizador' => [
        'name' => 'Visualizador',
        'level' => 1,
        'permissions' => ['read']
    ],
    'controlador' => [
        'name' => 'Controlador',
        'level' => 2,
        'permissions' => ['read', 'create', 'update']
    ],
    'administrador' => [
        'name' => 'Administrador',
        'level' => 3,
        'permissions' => ['read', 'create', 'update', 'delete', 'manage_users']
    ],
    'gerente' => [
        'name' => 'Gerente',
        'level' => 4,
        'permissions' => ['read', 'create', 'update', 'delete', 'manage_users', 'manage_system']
    ]
]);

// Status de funcionários
define('EMPLOYEE_STATUS', [
    'ativo' => 'Ativo',
    'inativo' => 'Inativo',
    'afastado' => 'Afastado'
]);

// Status de documentos/treinamentos
define('DOCUMENT_STATUS', [
    'valido' => ['label' => 'Válido', 'color' => 'success', 'icon' => 'check-circle'],
    'vence_30_dias' => ['label' => 'Vence em 30 dias', 'color' => 'warning', 'icon' => 'exclamation-triangle'],
    'vence_15_dias' => ['label' => 'Vence em 15 dias', 'color' => 'warning', 'icon' => 'exclamation-triangle'],
    'vencido' => ['label' => 'Vencido', 'color' => 'danger', 'icon' => 'times-circle'],
    'sem_documento' => ['label' => 'Sem documento', 'color' => 'secondary', 'icon' => 'question-circle']
]);

/**
 * Função para obter configuração do banco
 */
function getConfig($key, $default = null) {
    static $configs = null;
    
    if ($configs === null) {
        try {
            $db = getDB();
            $result = $db->fetchAll("SELECT chave, valor, tipo FROM configuracoes");
            $configs = [];
            
            foreach ($result as $config) {
                $value = $config['valor'];
                
                // Converte o valor baseado no tipo
                switch ($config['tipo']) {
                    case 'number':
                        $value = is_numeric($value) ? (float)$value : $value;
                        break;
                    case 'boolean':
                        $value = filter_var($value, FILTER_VALIDATE_BOOLEAN);
                        break;
                    case 'json':
                        $value = json_decode($value, true);
                        break;
                }
                
                $configs[$config['chave']] = $value;
            }
        } catch (Exception $e) {
            error_log("Erro ao carregar configurações: " . $e->getMessage());
            $configs = [];
        }
    }
    
    return isset($configs[$key]) ? $configs[$key] : $default;
}

/**
 * Função para verificar se o usuário tem permissão
 */
function hasPermission($permission, $userHierarchy = null) {
    if ($userHierarchy === null) {
        $userHierarchy = $_SESSION['user_hierarchy'] ?? 'visualizador';
    }
    
    $hierarchies = USER_HIERARCHIES;
    
    if (!isset($hierarchies[$userHierarchy])) {
        return false;
    }
    
    return in_array($permission, $hierarchies[$userHierarchy]['permissions']);
}

/**
 * Função para gerar token CSRF
 */
function generateCSRFToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Função para verificar token CSRF
 */
function verifyCSRFToken($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * Função para sanitizar entrada
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Função para validar CPF
 */
function validateCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    if (strlen($cpf) != 11 || preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }
    
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    
    return true;
}

/**
 * Função para validar CNPJ
 */
function validateCNPJ($cnpj) {
    $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
    
    if (strlen($cnpj) != 14) {
        return false;
    }
    
    // Verifica se todos os dígitos são iguais
    if (preg_match('/(\d)\1{13}/', $cnpj)) {
        return false;
    }
    
    // Calcula os dígitos verificadores
    $length = strlen($cnpj) - 2;
    $numbers = substr($cnpj, 0, $length);
    $digits = substr($cnpj, $length);
    $sum = 0;
    $pos = $length - 7;
    
    for ($i = $length; $i >= 1; $i--) {
        $sum += $numbers[$length - $i] * $pos--;
        if ($pos < 2) {
            $pos = 9;
        }
    }
    
    $result = $sum % 11 < 2 ? 0 : 11 - $sum % 11;
    
    if ($result != $digits[0]) {
        return false;
    }
    
    $length = $length + 1;
    $numbers = substr($cnpj, 0, $length);
    $sum = 0;
    $pos = $length - 7;
    
    for ($i = $length; $i >= 1; $i--) {
        $sum += $numbers[$length - $i] * $pos--;
        if ($pos < 2) {
            $pos = 9;
        }
    }
    
    $result = $sum % 11 < 2 ? 0 : 11 - $sum % 11;
    
    return $result == $digits[1];
}

/**
 * Função para formatar CPF
 */
function formatCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $cpf);
}

/**
 * Função para formatar CNPJ
 */
function formatCNPJ($cnpj) {
    $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
    return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $cnpj);
}

/**
 * Função para calcular status de documento baseado na data de vencimento
 */
function getDocumentStatus($expirationDate) {
    if (empty($expirationDate)) {
        return 'sem_documento';
    }
    
    $today = new DateTime();
    $expiry = new DateTime($expirationDate);
    $diff = $today->diff($expiry);
    
    if ($expiry < $today) {
        return 'vencido';
    } elseif ($diff->days <= 15) {
        return 'vence_15_dias';
    } elseif ($diff->days <= 30) {
        return 'vence_30_dias';
    } else {
        return 'valido';
    }
}

// Incluir arquivo de banco de dados
require_once __DIR__ . '/database.php';

// Incluir arquivo de autenticação
require_once __DIR__ . '/../includes/auth.php';
?>